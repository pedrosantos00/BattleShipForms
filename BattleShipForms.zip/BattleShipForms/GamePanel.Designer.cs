﻿namespace BattleShipForms
{
    partial class GamePanel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        public void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label49 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.j10 = new System.Windows.Forms.Button();
            this.j9 = new System.Windows.Forms.Button();
            this.j8 = new System.Windows.Forms.Button();
            this.j7 = new System.Windows.Forms.Button();
            this.j6 = new System.Windows.Forms.Button();
            this.j5 = new System.Windows.Forms.Button();
            this.j4 = new System.Windows.Forms.Button();
            this.j3 = new System.Windows.Forms.Button();
            this.j2 = new System.Windows.Forms.Button();
            this.j1 = new System.Windows.Forms.Button();
            this.i10 = new System.Windows.Forms.Button();
            this.i9 = new System.Windows.Forms.Button();
            this.i8 = new System.Windows.Forms.Button();
            this.i7 = new System.Windows.Forms.Button();
            this.i6 = new System.Windows.Forms.Button();
            this.i5 = new System.Windows.Forms.Button();
            this.i4 = new System.Windows.Forms.Button();
            this.i3 = new System.Windows.Forms.Button();
            this.i2 = new System.Windows.Forms.Button();
            this.i1 = new System.Windows.Forms.Button();
            this.h10 = new System.Windows.Forms.Button();
            this.h9 = new System.Windows.Forms.Button();
            this.h8 = new System.Windows.Forms.Button();
            this.h7 = new System.Windows.Forms.Button();
            this.h6 = new System.Windows.Forms.Button();
            this.h5 = new System.Windows.Forms.Button();
            this.h4 = new System.Windows.Forms.Button();
            this.h3 = new System.Windows.Forms.Button();
            this.h2 = new System.Windows.Forms.Button();
            this.h1 = new System.Windows.Forms.Button();
            this.g10 = new System.Windows.Forms.Button();
            this.g9 = new System.Windows.Forms.Button();
            this.g8 = new System.Windows.Forms.Button();
            this.g7 = new System.Windows.Forms.Button();
            this.g6 = new System.Windows.Forms.Button();
            this.g5 = new System.Windows.Forms.Button();
            this.g4 = new System.Windows.Forms.Button();
            this.g3 = new System.Windows.Forms.Button();
            this.g2 = new System.Windows.Forms.Button();
            this.g1 = new System.Windows.Forms.Button();
            this.f10 = new System.Windows.Forms.Button();
            this.f9 = new System.Windows.Forms.Button();
            this.f8 = new System.Windows.Forms.Button();
            this.f7 = new System.Windows.Forms.Button();
            this.f6 = new System.Windows.Forms.Button();
            this.f5 = new System.Windows.Forms.Button();
            this.f4 = new System.Windows.Forms.Button();
            this.f3 = new System.Windows.Forms.Button();
            this.f2 = new System.Windows.Forms.Button();
            this.f1 = new System.Windows.Forms.Button();
            this.e10 = new System.Windows.Forms.Button();
            this.e9 = new System.Windows.Forms.Button();
            this.e8 = new System.Windows.Forms.Button();
            this.e7 = new System.Windows.Forms.Button();
            this.e6 = new System.Windows.Forms.Button();
            this.e5 = new System.Windows.Forms.Button();
            this.e4 = new System.Windows.Forms.Button();
            this.e3 = new System.Windows.Forms.Button();
            this.e2 = new System.Windows.Forms.Button();
            this.e1 = new System.Windows.Forms.Button();
            this.d10 = new System.Windows.Forms.Button();
            this.d9 = new System.Windows.Forms.Button();
            this.d8 = new System.Windows.Forms.Button();
            this.d7 = new System.Windows.Forms.Button();
            this.d6 = new System.Windows.Forms.Button();
            this.d5 = new System.Windows.Forms.Button();
            this.d4 = new System.Windows.Forms.Button();
            this.d3 = new System.Windows.Forms.Button();
            this.d2 = new System.Windows.Forms.Button();
            this.d1 = new System.Windows.Forms.Button();
            this.c10 = new System.Windows.Forms.Button();
            this.c9 = new System.Windows.Forms.Button();
            this.c8 = new System.Windows.Forms.Button();
            this.c7 = new System.Windows.Forms.Button();
            this.c6 = new System.Windows.Forms.Button();
            this.c5 = new System.Windows.Forms.Button();
            this.c4 = new System.Windows.Forms.Button();
            this.c3 = new System.Windows.Forms.Button();
            this.c2 = new System.Windows.Forms.Button();
            this.c1 = new System.Windows.Forms.Button();
            this.b10 = new System.Windows.Forms.Button();
            this.b9 = new System.Windows.Forms.Button();
            this.bb8 = new System.Windows.Forms.Button();
            this.b7 = new System.Windows.Forms.Button();
            this.b6 = new System.Windows.Forms.Button();
            this.b5 = new System.Windows.Forms.Button();
            this.b4 = new System.Windows.Forms.Button();
            this.b3 = new System.Windows.Forms.Button();
            this.b2 = new System.Windows.Forms.Button();
            this.b1 = new System.Windows.Forms.Button();
            this.a10 = new System.Windows.Forms.Button();
            this.a9 = new System.Windows.Forms.Button();
            this.a8 = new System.Windows.Forms.Button();
            this.a7 = new System.Windows.Forms.Button();
            this.a6 = new System.Windows.Forms.Button();
            this.a5 = new System.Windows.Forms.Button();
            this.a4 = new System.Windows.Forms.Button();
            this.a3 = new System.Windows.Forms.Button();
            this.a2 = new System.Windows.Forms.Button();
            this.a1 = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.button34 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.button37 = new System.Windows.Forms.Button();
            this.button38 = new System.Windows.Forms.Button();
            this.button39 = new System.Windows.Forms.Button();
            this.button40 = new System.Windows.Forms.Button();
            this.button41 = new System.Windows.Forms.Button();
            this.button42 = new System.Windows.Forms.Button();
            this.button43 = new System.Windows.Forms.Button();
            this.button44 = new System.Windows.Forms.Button();
            this.button45 = new System.Windows.Forms.Button();
            this.button46 = new System.Windows.Forms.Button();
            this.button47 = new System.Windows.Forms.Button();
            this.button48 = new System.Windows.Forms.Button();
            this.button49 = new System.Windows.Forms.Button();
            this.button50 = new System.Windows.Forms.Button();
            this.button51 = new System.Windows.Forms.Button();
            this.button52 = new System.Windows.Forms.Button();
            this.button53 = new System.Windows.Forms.Button();
            this.button54 = new System.Windows.Forms.Button();
            this.button55 = new System.Windows.Forms.Button();
            this.button56 = new System.Windows.Forms.Button();
            this.button57 = new System.Windows.Forms.Button();
            this.button58 = new System.Windows.Forms.Button();
            this.button59 = new System.Windows.Forms.Button();
            this.button60 = new System.Windows.Forms.Button();
            this.button61 = new System.Windows.Forms.Button();
            this.button62 = new System.Windows.Forms.Button();
            this.button63 = new System.Windows.Forms.Button();
            this.button64 = new System.Windows.Forms.Button();
            this.button65 = new System.Windows.Forms.Button();
            this.button66 = new System.Windows.Forms.Button();
            this.button67 = new System.Windows.Forms.Button();
            this.button68 = new System.Windows.Forms.Button();
            this.button69 = new System.Windows.Forms.Button();
            this.button70 = new System.Windows.Forms.Button();
            this.button71 = new System.Windows.Forms.Button();
            this.button72 = new System.Windows.Forms.Button();
            this.button73 = new System.Windows.Forms.Button();
            this.button74 = new System.Windows.Forms.Button();
            this.button75 = new System.Windows.Forms.Button();
            this.button76 = new System.Windows.Forms.Button();
            this.button77 = new System.Windows.Forms.Button();
            this.button78 = new System.Windows.Forms.Button();
            this.button79 = new System.Windows.Forms.Button();
            this.button80 = new System.Windows.Forms.Button();
            this.button81 = new System.Windows.Forms.Button();
            this.button82 = new System.Windows.Forms.Button();
            this.button83 = new System.Windows.Forms.Button();
            this.button84 = new System.Windows.Forms.Button();
            this.button85 = new System.Windows.Forms.Button();
            this.button86 = new System.Windows.Forms.Button();
            this.button87 = new System.Windows.Forms.Button();
            this.button88 = new System.Windows.Forms.Button();
            this.button89 = new System.Windows.Forms.Button();
            this.button90 = new System.Windows.Forms.Button();
            this.button91 = new System.Windows.Forms.Button();
            this.button92 = new System.Windows.Forms.Button();
            this.button93 = new System.Windows.Forms.Button();
            this.button94 = new System.Windows.Forms.Button();
            this.button95 = new System.Windows.Forms.Button();
            this.button96 = new System.Windows.Forms.Button();
            this.button97 = new System.Windows.Forms.Button();
            this.button98 = new System.Windows.Forms.Button();
            this.button99 = new System.Windows.Forms.Button();
            this.button100 = new System.Windows.Forms.Button();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.button101 = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Controls.Add(this.label49);
            this.panel1.Controls.Add(this.label46);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(782, 91);
            this.panel1.TabIndex = 0;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.BackColor = System.Drawing.Color.Cyan;
            this.label49.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label49.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label49.Location = new System.Drawing.Point(3, 62);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(399, 20);
            this.label49.TabIndex = 3;
            this.label49.Text = "Please add your Ship into Board by choosing the square";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Arial Black", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label46.Location = new System.Drawing.Point(273, 9);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(206, 30);
            this.label46.TabIndex = 0;
            this.label46.Text = "BattelShip Game";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label51.Location = new System.Drawing.Point(305, 186);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(134, 16);
            this.label51.TabIndex = 4;
            this.label51.Text = "Current boat to add:";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(352, 151);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(33, 18);
            this.label48.TabIndex = 2;
            this.label48.Text = "You";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label47.Location = new System.Drawing.Point(344, 132);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(50, 19);
            this.label47.TabIndex = 1;
            this.label47.Text = "Turn:";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label16);
            this.panel2.Controls.Add(this.label17);
            this.panel2.Controls.Add(this.label18);
            this.panel2.Controls.Add(this.label19);
            this.panel2.Controls.Add(this.label20);
            this.panel2.Controls.Add(this.label15);
            this.panel2.Controls.Add(this.label14);
            this.panel2.Controls.Add(this.label13);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.j10);
            this.panel2.Controls.Add(this.j9);
            this.panel2.Controls.Add(this.j8);
            this.panel2.Controls.Add(this.j7);
            this.panel2.Controls.Add(this.j6);
            this.panel2.Controls.Add(this.j5);
            this.panel2.Controls.Add(this.j4);
            this.panel2.Controls.Add(this.j3);
            this.panel2.Controls.Add(this.j2);
            this.panel2.Controls.Add(this.j1);
            this.panel2.Controls.Add(this.i10);
            this.panel2.Controls.Add(this.i9);
            this.panel2.Controls.Add(this.i8);
            this.panel2.Controls.Add(this.i7);
            this.panel2.Controls.Add(this.i6);
            this.panel2.Controls.Add(this.i5);
            this.panel2.Controls.Add(this.i4);
            this.panel2.Controls.Add(this.i3);
            this.panel2.Controls.Add(this.i2);
            this.panel2.Controls.Add(this.i1);
            this.panel2.Controls.Add(this.h10);
            this.panel2.Controls.Add(this.h9);
            this.panel2.Controls.Add(this.h8);
            this.panel2.Controls.Add(this.h7);
            this.panel2.Controls.Add(this.h6);
            this.panel2.Controls.Add(this.h5);
            this.panel2.Controls.Add(this.h4);
            this.panel2.Controls.Add(this.h3);
            this.panel2.Controls.Add(this.h2);
            this.panel2.Controls.Add(this.h1);
            this.panel2.Controls.Add(this.g10);
            this.panel2.Controls.Add(this.g9);
            this.panel2.Controls.Add(this.g8);
            this.panel2.Controls.Add(this.g7);
            this.panel2.Controls.Add(this.g6);
            this.panel2.Controls.Add(this.g5);
            this.panel2.Controls.Add(this.g4);
            this.panel2.Controls.Add(this.g3);
            this.panel2.Controls.Add(this.g2);
            this.panel2.Controls.Add(this.g1);
            this.panel2.Controls.Add(this.f10);
            this.panel2.Controls.Add(this.f9);
            this.panel2.Controls.Add(this.f8);
            this.panel2.Controls.Add(this.f7);
            this.panel2.Controls.Add(this.f6);
            this.panel2.Controls.Add(this.f5);
            this.panel2.Controls.Add(this.f4);
            this.panel2.Controls.Add(this.f3);
            this.panel2.Controls.Add(this.f2);
            this.panel2.Controls.Add(this.f1);
            this.panel2.Controls.Add(this.e10);
            this.panel2.Controls.Add(this.e9);
            this.panel2.Controls.Add(this.e8);
            this.panel2.Controls.Add(this.e7);
            this.panel2.Controls.Add(this.e6);
            this.panel2.Controls.Add(this.e5);
            this.panel2.Controls.Add(this.e4);
            this.panel2.Controls.Add(this.e3);
            this.panel2.Controls.Add(this.e2);
            this.panel2.Controls.Add(this.e1);
            this.panel2.Controls.Add(this.d10);
            this.panel2.Controls.Add(this.d9);
            this.panel2.Controls.Add(this.d8);
            this.panel2.Controls.Add(this.d7);
            this.panel2.Controls.Add(this.d6);
            this.panel2.Controls.Add(this.d5);
            this.panel2.Controls.Add(this.d4);
            this.panel2.Controls.Add(this.d3);
            this.panel2.Controls.Add(this.d2);
            this.panel2.Controls.Add(this.d1);
            this.panel2.Controls.Add(this.c10);
            this.panel2.Controls.Add(this.c9);
            this.panel2.Controls.Add(this.c8);
            this.panel2.Controls.Add(this.c7);
            this.panel2.Controls.Add(this.c6);
            this.panel2.Controls.Add(this.c5);
            this.panel2.Controls.Add(this.c4);
            this.panel2.Controls.Add(this.c3);
            this.panel2.Controls.Add(this.c2);
            this.panel2.Controls.Add(this.c1);
            this.panel2.Controls.Add(this.b10);
            this.panel2.Controls.Add(this.b9);
            this.panel2.Controls.Add(this.bb8);
            this.panel2.Controls.Add(this.b7);
            this.panel2.Controls.Add(this.b6);
            this.panel2.Controls.Add(this.b5);
            this.panel2.Controls.Add(this.b4);
            this.panel2.Controls.Add(this.b3);
            this.panel2.Controls.Add(this.b2);
            this.panel2.Controls.Add(this.b1);
            this.panel2.Controls.Add(this.a10);
            this.panel2.Controls.Add(this.a9);
            this.panel2.Controls.Add(this.a8);
            this.panel2.Controls.Add(this.a7);
            this.panel2.Controls.Add(this.a6);
            this.panel2.Controls.Add(this.a5);
            this.panel2.Controls.Add(this.a4);
            this.panel2.Controls.Add(this.a3);
            this.panel2.Controls.Add(this.a2);
            this.panel2.Controls.Add(this.a1);
            this.panel2.Location = new System.Drawing.Point(12, 119);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(288, 285);
            this.panel2.TabIndex = 1;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label16.Location = new System.Drawing.Point(261, 3);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(16, 20);
            this.label16.TabIndex = 119;
            this.label16.Text = "J";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label17.Location = new System.Drawing.Point(235, 3);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(13, 20);
            this.label17.TabIndex = 118;
            this.label17.Text = "I";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label18.Location = new System.Drawing.Point(209, 3);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(18, 20);
            this.label18.TabIndex = 117;
            this.label18.Text = "H";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label19.Location = new System.Drawing.Point(183, 3);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(19, 20);
            this.label19.TabIndex = 116;
            this.label19.Text = "G";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label20.Location = new System.Drawing.Point(157, 3);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(17, 20);
            this.label20.TabIndex = 115;
            this.label20.Text = "F";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label15.Location = new System.Drawing.Point(131, 3);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(18, 20);
            this.label15.TabIndex = 114;
            this.label15.Text = "E";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label14.Location = new System.Drawing.Point(105, 3);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(18, 20);
            this.label14.TabIndex = 113;
            this.label14.Text = "D";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label13.Location = new System.Drawing.Point(79, 3);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(18, 20);
            this.label13.TabIndex = 112;
            this.label13.Text = "C";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label12.Location = new System.Drawing.Point(53, 3);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(18, 20);
            this.label12.TabIndex = 111;
            this.label12.Text = "B";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label11.Location = new System.Drawing.Point(27, 3);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(18, 20);
            this.label11.TabIndex = 110;
            this.label11.Text = "A";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(5, 260);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(23, 20);
            this.label6.TabIndex = 109;
            this.label6.Text = "10";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(5, 234);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(16, 20);
            this.label7.TabIndex = 108;
            this.label7.Text = "9";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label8.Location = new System.Drawing.Point(5, 208);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(16, 20);
            this.label8.TabIndex = 107;
            this.label8.Text = "8";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label9.Location = new System.Drawing.Point(5, 182);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(16, 20);
            this.label9.TabIndex = 106;
            this.label9.Text = "7";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label10.Location = new System.Drawing.Point(5, 156);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(16, 20);
            this.label10.TabIndex = 105;
            this.label10.Text = "6";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(5, 130);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(16, 20);
            this.label5.TabIndex = 104;
            this.label5.Text = "5";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(5, 104);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(16, 20);
            this.label4.TabIndex = 103;
            this.label4.Text = "4";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(5, 78);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(16, 20);
            this.label3.TabIndex = 102;
            this.label3.Text = "3";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(5, 52);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(16, 20);
            this.label2.TabIndex = 101;
            this.label2.Text = "2";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(5, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(16, 20);
            this.label1.TabIndex = 100;
            this.label1.Text = "1";
            // 
            // j10
            // 
            this.j10.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.j10.FlatAppearance.BorderSize = 0;
            this.j10.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.j10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.j10.Location = new System.Drawing.Point(261, 260);
            this.j10.Name = "j10";
            this.j10.Size = new System.Drawing.Size(20, 20);
            this.j10.TabIndex = 99;
            this.j10.UseVisualStyleBackColor = false;
            // 
            // j9
            // 
            this.j9.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.j9.FlatAppearance.BorderSize = 0;
            this.j9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.j9.Location = new System.Drawing.Point(261, 234);
            this.j9.Name = "j9";
            this.j9.Size = new System.Drawing.Size(20, 20);
            this.j9.TabIndex = 98;
            this.j9.UseVisualStyleBackColor = false;
            // 
            // j8
            // 
            this.j8.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.j8.FlatAppearance.BorderSize = 0;
            this.j8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.j8.Location = new System.Drawing.Point(261, 208);
            this.j8.Name = "j8";
            this.j8.Size = new System.Drawing.Size(20, 20);
            this.j8.TabIndex = 97;
            this.j8.UseVisualStyleBackColor = false;
            // 
            // j7
            // 
            this.j7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.j7.FlatAppearance.BorderSize = 0;
            this.j7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.j7.Location = new System.Drawing.Point(261, 182);
            this.j7.Name = "j7";
            this.j7.Size = new System.Drawing.Size(20, 20);
            this.j7.TabIndex = 96;
            this.j7.UseVisualStyleBackColor = false;
            // 
            // j6
            // 
            this.j6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.j6.FlatAppearance.BorderSize = 0;
            this.j6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.j6.Location = new System.Drawing.Point(261, 156);
            this.j6.Name = "j6";
            this.j6.Size = new System.Drawing.Size(20, 20);
            this.j6.TabIndex = 95;
            this.j6.UseVisualStyleBackColor = false;
            // 
            // j5
            // 
            this.j5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.j5.FlatAppearance.BorderSize = 0;
            this.j5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.j5.Location = new System.Drawing.Point(261, 130);
            this.j5.Name = "j5";
            this.j5.Size = new System.Drawing.Size(20, 20);
            this.j5.TabIndex = 94;
            this.j5.UseVisualStyleBackColor = false;
            // 
            // j4
            // 
            this.j4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.j4.FlatAppearance.BorderSize = 0;
            this.j4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.j4.Location = new System.Drawing.Point(261, 104);
            this.j4.Name = "j4";
            this.j4.Size = new System.Drawing.Size(20, 20);
            this.j4.TabIndex = 93;
            this.j4.UseVisualStyleBackColor = false;
            // 
            // j3
            // 
            this.j3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.j3.FlatAppearance.BorderSize = 0;
            this.j3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.j3.Location = new System.Drawing.Point(261, 78);
            this.j3.Name = "j3";
            this.j3.Size = new System.Drawing.Size(20, 20);
            this.j3.TabIndex = 92;
            this.j3.UseVisualStyleBackColor = false;
            // 
            // j2
            // 
            this.j2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.j2.FlatAppearance.BorderSize = 0;
            this.j2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.j2.Location = new System.Drawing.Point(261, 52);
            this.j2.Name = "j2";
            this.j2.Size = new System.Drawing.Size(20, 20);
            this.j2.TabIndex = 91;
            this.j2.UseVisualStyleBackColor = false;
            // 
            // j1
            // 
            this.j1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.j1.FlatAppearance.BorderSize = 0;
            this.j1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.j1.Location = new System.Drawing.Point(261, 26);
            this.j1.Name = "j1";
            this.j1.Size = new System.Drawing.Size(20, 20);
            this.j1.TabIndex = 90;
            this.j1.UseVisualStyleBackColor = false;
            // 
            // i10
            // 
            this.i10.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.i10.FlatAppearance.BorderSize = 0;
            this.i10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.i10.Location = new System.Drawing.Point(235, 260);
            this.i10.Name = "i10";
            this.i10.Size = new System.Drawing.Size(20, 20);
            this.i10.TabIndex = 89;
            this.i10.UseVisualStyleBackColor = false;
            // 
            // i9
            // 
            this.i9.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.i9.FlatAppearance.BorderSize = 0;
            this.i9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.i9.Location = new System.Drawing.Point(235, 234);
            this.i9.Name = "i9";
            this.i9.Size = new System.Drawing.Size(20, 20);
            this.i9.TabIndex = 88;
            this.i9.UseVisualStyleBackColor = false;
            // 
            // i8
            // 
            this.i8.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.i8.FlatAppearance.BorderSize = 0;
            this.i8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.i8.Location = new System.Drawing.Point(235, 208);
            this.i8.Name = "i8";
            this.i8.Size = new System.Drawing.Size(20, 20);
            this.i8.TabIndex = 87;
            this.i8.UseVisualStyleBackColor = false;
            // 
            // i7
            // 
            this.i7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.i7.FlatAppearance.BorderSize = 0;
            this.i7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.i7.Location = new System.Drawing.Point(235, 182);
            this.i7.Name = "i7";
            this.i7.Size = new System.Drawing.Size(20, 20);
            this.i7.TabIndex = 86;
            this.i7.UseVisualStyleBackColor = false;
            // 
            // i6
            // 
            this.i6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.i6.FlatAppearance.BorderSize = 0;
            this.i6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.i6.Location = new System.Drawing.Point(235, 156);
            this.i6.Name = "i6";
            this.i6.Size = new System.Drawing.Size(20, 20);
            this.i6.TabIndex = 85;
            this.i6.UseVisualStyleBackColor = false;
            // 
            // i5
            // 
            this.i5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.i5.FlatAppearance.BorderSize = 0;
            this.i5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.i5.Location = new System.Drawing.Point(235, 130);
            this.i5.Name = "i5";
            this.i5.Size = new System.Drawing.Size(20, 20);
            this.i5.TabIndex = 84;
            this.i5.UseVisualStyleBackColor = false;
            // 
            // i4
            // 
            this.i4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.i4.FlatAppearance.BorderSize = 0;
            this.i4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.i4.Location = new System.Drawing.Point(235, 104);
            this.i4.Name = "i4";
            this.i4.Size = new System.Drawing.Size(20, 20);
            this.i4.TabIndex = 83;
            this.i4.UseVisualStyleBackColor = false;
            // 
            // i3
            // 
            this.i3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.i3.FlatAppearance.BorderSize = 0;
            this.i3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.i3.Location = new System.Drawing.Point(235, 78);
            this.i3.Name = "i3";
            this.i3.Size = new System.Drawing.Size(20, 20);
            this.i3.TabIndex = 82;
            this.i3.UseVisualStyleBackColor = false;
            // 
            // i2
            // 
            this.i2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.i2.FlatAppearance.BorderSize = 0;
            this.i2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.i2.Location = new System.Drawing.Point(235, 52);
            this.i2.Name = "i2";
            this.i2.Size = new System.Drawing.Size(20, 20);
            this.i2.TabIndex = 81;
            this.i2.UseVisualStyleBackColor = false;
            // 
            // i1
            // 
            this.i1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.i1.FlatAppearance.BorderSize = 0;
            this.i1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.i1.Location = new System.Drawing.Point(235, 26);
            this.i1.Name = "i1";
            this.i1.Size = new System.Drawing.Size(20, 20);
            this.i1.TabIndex = 80;
            this.i1.UseVisualStyleBackColor = false;
            // 
            // h10
            // 
            this.h10.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.h10.FlatAppearance.BorderSize = 0;
            this.h10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.h10.Location = new System.Drawing.Point(209, 260);
            this.h10.Name = "h10";
            this.h10.Size = new System.Drawing.Size(20, 20);
            this.h10.TabIndex = 79;
            this.h10.UseVisualStyleBackColor = false;
            // 
            // h9
            // 
            this.h9.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.h9.FlatAppearance.BorderSize = 0;
            this.h9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.h9.Location = new System.Drawing.Point(209, 234);
            this.h9.Name = "h9";
            this.h9.Size = new System.Drawing.Size(20, 20);
            this.h9.TabIndex = 78;
            this.h9.UseVisualStyleBackColor = false;
            // 
            // h8
            // 
            this.h8.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.h8.FlatAppearance.BorderSize = 0;
            this.h8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.h8.Location = new System.Drawing.Point(209, 208);
            this.h8.Name = "h8";
            this.h8.Size = new System.Drawing.Size(20, 20);
            this.h8.TabIndex = 77;
            this.h8.UseVisualStyleBackColor = false;
            // 
            // h7
            // 
            this.h7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.h7.FlatAppearance.BorderSize = 0;
            this.h7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.h7.Location = new System.Drawing.Point(209, 182);
            this.h7.Name = "h7";
            this.h7.Size = new System.Drawing.Size(20, 20);
            this.h7.TabIndex = 76;
            this.h7.UseVisualStyleBackColor = false;
            // 
            // h6
            // 
            this.h6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.h6.FlatAppearance.BorderSize = 0;
            this.h6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.h6.Location = new System.Drawing.Point(209, 156);
            this.h6.Name = "h6";
            this.h6.Size = new System.Drawing.Size(20, 20);
            this.h6.TabIndex = 75;
            this.h6.UseVisualStyleBackColor = false;
            // 
            // h5
            // 
            this.h5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.h5.FlatAppearance.BorderSize = 0;
            this.h5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.h5.Location = new System.Drawing.Point(209, 130);
            this.h5.Name = "h5";
            this.h5.Size = new System.Drawing.Size(20, 20);
            this.h5.TabIndex = 74;
            this.h5.UseVisualStyleBackColor = false;
            // 
            // h4
            // 
            this.h4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.h4.FlatAppearance.BorderSize = 0;
            this.h4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.h4.Location = new System.Drawing.Point(209, 104);
            this.h4.Name = "h4";
            this.h4.Size = new System.Drawing.Size(20, 20);
            this.h4.TabIndex = 73;
            this.h4.UseVisualStyleBackColor = false;
            // 
            // h3
            // 
            this.h3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.h3.FlatAppearance.BorderSize = 0;
            this.h3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.h3.Location = new System.Drawing.Point(209, 78);
            this.h3.Name = "h3";
            this.h3.Size = new System.Drawing.Size(20, 20);
            this.h3.TabIndex = 72;
            this.h3.UseVisualStyleBackColor = false;
            // 
            // h2
            // 
            this.h2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.h2.FlatAppearance.BorderSize = 0;
            this.h2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.h2.Location = new System.Drawing.Point(209, 52);
            this.h2.Name = "h2";
            this.h2.Size = new System.Drawing.Size(20, 20);
            this.h2.TabIndex = 71;
            this.h2.UseVisualStyleBackColor = false;
            // 
            // h1
            // 
            this.h1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.h1.FlatAppearance.BorderSize = 0;
            this.h1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.h1.Location = new System.Drawing.Point(209, 26);
            this.h1.Name = "h1";
            this.h1.Size = new System.Drawing.Size(20, 20);
            this.h1.TabIndex = 70;
            this.h1.UseVisualStyleBackColor = false;
            // 
            // g10
            // 
            this.g10.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.g10.FlatAppearance.BorderSize = 0;
            this.g10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.g10.Location = new System.Drawing.Point(183, 260);
            this.g10.Name = "g10";
            this.g10.Size = new System.Drawing.Size(20, 20);
            this.g10.TabIndex = 69;
            this.g10.UseVisualStyleBackColor = false;
            // 
            // g9
            // 
            this.g9.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.g9.FlatAppearance.BorderSize = 0;
            this.g9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.g9.Location = new System.Drawing.Point(183, 234);
            this.g9.Name = "g9";
            this.g9.Size = new System.Drawing.Size(20, 20);
            this.g9.TabIndex = 68;
            this.g9.UseVisualStyleBackColor = false;
            // 
            // g8
            // 
            this.g8.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.g8.FlatAppearance.BorderSize = 0;
            this.g8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.g8.Location = new System.Drawing.Point(183, 208);
            this.g8.Name = "g8";
            this.g8.Size = new System.Drawing.Size(20, 20);
            this.g8.TabIndex = 67;
            this.g8.UseVisualStyleBackColor = false;
            // 
            // g7
            // 
            this.g7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.g7.FlatAppearance.BorderSize = 0;
            this.g7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.g7.Location = new System.Drawing.Point(183, 182);
            this.g7.Name = "g7";
            this.g7.Size = new System.Drawing.Size(20, 20);
            this.g7.TabIndex = 66;
            this.g7.UseVisualStyleBackColor = false;
            // 
            // g6
            // 
            this.g6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.g6.FlatAppearance.BorderSize = 0;
            this.g6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.g6.Location = new System.Drawing.Point(183, 156);
            this.g6.Name = "g6";
            this.g6.Size = new System.Drawing.Size(20, 20);
            this.g6.TabIndex = 65;
            this.g6.UseVisualStyleBackColor = false;
            // 
            // g5
            // 
            this.g5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.g5.FlatAppearance.BorderSize = 0;
            this.g5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.g5.Location = new System.Drawing.Point(183, 130);
            this.g5.Name = "g5";
            this.g5.Size = new System.Drawing.Size(20, 20);
            this.g5.TabIndex = 64;
            this.g5.UseVisualStyleBackColor = false;
            // 
            // g4
            // 
            this.g4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.g4.FlatAppearance.BorderSize = 0;
            this.g4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.g4.Location = new System.Drawing.Point(183, 104);
            this.g4.Name = "g4";
            this.g4.Size = new System.Drawing.Size(20, 20);
            this.g4.TabIndex = 63;
            this.g4.UseVisualStyleBackColor = false;
            // 
            // g3
            // 
            this.g3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.g3.FlatAppearance.BorderSize = 0;
            this.g3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.g3.Location = new System.Drawing.Point(183, 78);
            this.g3.Name = "g3";
            this.g3.Size = new System.Drawing.Size(20, 20);
            this.g3.TabIndex = 62;
            this.g3.UseVisualStyleBackColor = false;
            // 
            // g2
            // 
            this.g2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.g2.FlatAppearance.BorderSize = 0;
            this.g2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.g2.Location = new System.Drawing.Point(183, 52);
            this.g2.Name = "g2";
            this.g2.Size = new System.Drawing.Size(20, 20);
            this.g2.TabIndex = 61;
            this.g2.UseVisualStyleBackColor = false;
            // 
            // g1
            // 
            this.g1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.g1.FlatAppearance.BorderSize = 0;
            this.g1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.g1.Location = new System.Drawing.Point(183, 26);
            this.g1.Name = "g1";
            this.g1.Size = new System.Drawing.Size(20, 20);
            this.g1.TabIndex = 60;
            this.g1.UseVisualStyleBackColor = false;
            // 
            // f10
            // 
            this.f10.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.f10.FlatAppearance.BorderSize = 0;
            this.f10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.f10.Location = new System.Drawing.Point(157, 260);
            this.f10.Name = "f10";
            this.f10.Size = new System.Drawing.Size(20, 20);
            this.f10.TabIndex = 59;
            this.f10.UseVisualStyleBackColor = false;
            // 
            // f9
            // 
            this.f9.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.f9.FlatAppearance.BorderSize = 0;
            this.f9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.f9.Location = new System.Drawing.Point(157, 234);
            this.f9.Name = "f9";
            this.f9.Size = new System.Drawing.Size(20, 20);
            this.f9.TabIndex = 58;
            this.f9.UseVisualStyleBackColor = false;
            // 
            // f8
            // 
            this.f8.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.f8.FlatAppearance.BorderSize = 0;
            this.f8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.f8.Location = new System.Drawing.Point(157, 208);
            this.f8.Name = "f8";
            this.f8.Size = new System.Drawing.Size(20, 20);
            this.f8.TabIndex = 57;
            this.f8.UseVisualStyleBackColor = false;
            // 
            // f7
            // 
            this.f7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.f7.FlatAppearance.BorderSize = 0;
            this.f7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.f7.Location = new System.Drawing.Point(157, 182);
            this.f7.Name = "f7";
            this.f7.Size = new System.Drawing.Size(20, 20);
            this.f7.TabIndex = 56;
            this.f7.UseVisualStyleBackColor = false;
            // 
            // f6
            // 
            this.f6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.f6.FlatAppearance.BorderSize = 0;
            this.f6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.f6.Location = new System.Drawing.Point(157, 156);
            this.f6.Name = "f6";
            this.f6.Size = new System.Drawing.Size(20, 20);
            this.f6.TabIndex = 55;
            this.f6.UseVisualStyleBackColor = false;
            // 
            // f5
            // 
            this.f5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.f5.FlatAppearance.BorderSize = 0;
            this.f5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.f5.Location = new System.Drawing.Point(157, 130);
            this.f5.Name = "f5";
            this.f5.Size = new System.Drawing.Size(20, 20);
            this.f5.TabIndex = 54;
            this.f5.UseVisualStyleBackColor = false;
            // 
            // f4
            // 
            this.f4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.f4.FlatAppearance.BorderSize = 0;
            this.f4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.f4.Location = new System.Drawing.Point(157, 104);
            this.f4.Name = "f4";
            this.f4.Size = new System.Drawing.Size(20, 20);
            this.f4.TabIndex = 53;
            this.f4.UseVisualStyleBackColor = false;
            // 
            // f3
            // 
            this.f3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.f3.FlatAppearance.BorderSize = 0;
            this.f3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.f3.Location = new System.Drawing.Point(157, 78);
            this.f3.Name = "f3";
            this.f3.Size = new System.Drawing.Size(20, 20);
            this.f3.TabIndex = 52;
            this.f3.UseVisualStyleBackColor = false;
            // 
            // f2
            // 
            this.f2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.f2.FlatAppearance.BorderSize = 0;
            this.f2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.f2.Location = new System.Drawing.Point(157, 52);
            this.f2.Name = "f2";
            this.f2.Size = new System.Drawing.Size(20, 20);
            this.f2.TabIndex = 51;
            this.f2.UseVisualStyleBackColor = false;
            // 
            // f1
            // 
            this.f1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.f1.FlatAppearance.BorderSize = 0;
            this.f1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.f1.Location = new System.Drawing.Point(157, 26);
            this.f1.Name = "f1";
            this.f1.Size = new System.Drawing.Size(20, 20);
            this.f1.TabIndex = 50;
            this.f1.UseVisualStyleBackColor = false;
            // 
            // e10
            // 
            this.e10.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.e10.FlatAppearance.BorderSize = 0;
            this.e10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.e10.Location = new System.Drawing.Point(131, 260);
            this.e10.Name = "e10";
            this.e10.Size = new System.Drawing.Size(20, 20);
            this.e10.TabIndex = 49;
            this.e10.UseVisualStyleBackColor = false;
            // 
            // e9
            // 
            this.e9.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.e9.FlatAppearance.BorderSize = 0;
            this.e9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.e9.Location = new System.Drawing.Point(131, 234);
            this.e9.Name = "e9";
            this.e9.Size = new System.Drawing.Size(20, 20);
            this.e9.TabIndex = 48;
            this.e9.UseVisualStyleBackColor = false;
            // 
            // e8
            // 
            this.e8.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.e8.FlatAppearance.BorderSize = 0;
            this.e8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.e8.Location = new System.Drawing.Point(131, 208);
            this.e8.Name = "e8";
            this.e8.Size = new System.Drawing.Size(20, 20);
            this.e8.TabIndex = 47;
            this.e8.UseVisualStyleBackColor = false;
            // 
            // e7
            // 
            this.e7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.e7.FlatAppearance.BorderSize = 0;
            this.e7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.e7.Location = new System.Drawing.Point(131, 182);
            this.e7.Name = "e7";
            this.e7.Size = new System.Drawing.Size(20, 20);
            this.e7.TabIndex = 46;
            this.e7.UseVisualStyleBackColor = false;
            // 
            // e6
            // 
            this.e6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.e6.FlatAppearance.BorderSize = 0;
            this.e6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.e6.Location = new System.Drawing.Point(131, 156);
            this.e6.Name = "e6";
            this.e6.Size = new System.Drawing.Size(20, 20);
            this.e6.TabIndex = 45;
            this.e6.UseVisualStyleBackColor = false;
            // 
            // e5
            // 
            this.e5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.e5.FlatAppearance.BorderSize = 0;
            this.e5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.e5.Location = new System.Drawing.Point(131, 130);
            this.e5.Name = "e5";
            this.e5.Size = new System.Drawing.Size(20, 20);
            this.e5.TabIndex = 44;
            this.e5.UseVisualStyleBackColor = false;
            // 
            // e4
            // 
            this.e4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.e4.FlatAppearance.BorderSize = 0;
            this.e4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.e4.Location = new System.Drawing.Point(131, 104);
            this.e4.Name = "e4";
            this.e4.Size = new System.Drawing.Size(20, 20);
            this.e4.TabIndex = 43;
            this.e4.UseVisualStyleBackColor = false;
            // 
            // e3
            // 
            this.e3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.e3.FlatAppearance.BorderSize = 0;
            this.e3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.e3.Location = new System.Drawing.Point(131, 78);
            this.e3.Name = "e3";
            this.e3.Size = new System.Drawing.Size(20, 20);
            this.e3.TabIndex = 42;
            this.e3.UseVisualStyleBackColor = false;
            // 
            // e2
            // 
            this.e2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.e2.FlatAppearance.BorderSize = 0;
            this.e2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.e2.Location = new System.Drawing.Point(131, 52);
            this.e2.Name = "e2";
            this.e2.Size = new System.Drawing.Size(20, 20);
            this.e2.TabIndex = 41;
            this.e2.UseVisualStyleBackColor = false;
            // 
            // e1
            // 
            this.e1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.e1.FlatAppearance.BorderSize = 0;
            this.e1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.e1.Location = new System.Drawing.Point(131, 26);
            this.e1.Name = "e1";
            this.e1.Size = new System.Drawing.Size(20, 20);
            this.e1.TabIndex = 40;
            this.e1.UseVisualStyleBackColor = false;
            // 
            // d10
            // 
            this.d10.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.d10.FlatAppearance.BorderSize = 0;
            this.d10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.d10.Location = new System.Drawing.Point(105, 260);
            this.d10.Name = "d10";
            this.d10.Size = new System.Drawing.Size(20, 20);
            this.d10.TabIndex = 39;
            this.d10.UseVisualStyleBackColor = false;
            // 
            // d9
            // 
            this.d9.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.d9.FlatAppearance.BorderSize = 0;
            this.d9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.d9.Location = new System.Drawing.Point(105, 234);
            this.d9.Name = "d9";
            this.d9.Size = new System.Drawing.Size(20, 20);
            this.d9.TabIndex = 38;
            this.d9.UseVisualStyleBackColor = false;
            // 
            // d8
            // 
            this.d8.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.d8.FlatAppearance.BorderSize = 0;
            this.d8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.d8.Location = new System.Drawing.Point(105, 208);
            this.d8.Name = "d8";
            this.d8.Size = new System.Drawing.Size(20, 20);
            this.d8.TabIndex = 37;
            this.d8.UseVisualStyleBackColor = false;
            // 
            // d7
            // 
            this.d7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.d7.FlatAppearance.BorderSize = 0;
            this.d7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.d7.Location = new System.Drawing.Point(105, 182);
            this.d7.Name = "d7";
            this.d7.Size = new System.Drawing.Size(20, 20);
            this.d7.TabIndex = 36;
            this.d7.UseVisualStyleBackColor = false;
            // 
            // d6
            // 
            this.d6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.d6.FlatAppearance.BorderSize = 0;
            this.d6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.d6.Location = new System.Drawing.Point(105, 156);
            this.d6.Name = "d6";
            this.d6.Size = new System.Drawing.Size(20, 20);
            this.d6.TabIndex = 35;
            this.d6.UseVisualStyleBackColor = false;
            // 
            // d5
            // 
            this.d5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.d5.FlatAppearance.BorderSize = 0;
            this.d5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.d5.Location = new System.Drawing.Point(105, 130);
            this.d5.Name = "d5";
            this.d5.Size = new System.Drawing.Size(20, 20);
            this.d5.TabIndex = 34;
            this.d5.UseVisualStyleBackColor = false;
            // 
            // d4
            // 
            this.d4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.d4.FlatAppearance.BorderSize = 0;
            this.d4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.d4.Location = new System.Drawing.Point(105, 104);
            this.d4.Name = "d4";
            this.d4.Size = new System.Drawing.Size(20, 20);
            this.d4.TabIndex = 33;
            this.d4.UseVisualStyleBackColor = false;
            // 
            // d3
            // 
            this.d3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.d3.FlatAppearance.BorderSize = 0;
            this.d3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.d3.Location = new System.Drawing.Point(105, 78);
            this.d3.Name = "d3";
            this.d3.Size = new System.Drawing.Size(20, 20);
            this.d3.TabIndex = 32;
            this.d3.UseVisualStyleBackColor = false;
            // 
            // d2
            // 
            this.d2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.d2.FlatAppearance.BorderSize = 0;
            this.d2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.d2.Location = new System.Drawing.Point(105, 52);
            this.d2.Name = "d2";
            this.d2.Size = new System.Drawing.Size(20, 20);
            this.d2.TabIndex = 31;
            this.d2.UseVisualStyleBackColor = false;
            // 
            // d1
            // 
            this.d1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.d1.FlatAppearance.BorderSize = 0;
            this.d1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.d1.Location = new System.Drawing.Point(105, 26);
            this.d1.Name = "d1";
            this.d1.Size = new System.Drawing.Size(20, 20);
            this.d1.TabIndex = 30;
            this.d1.UseVisualStyleBackColor = false;
            // 
            // c10
            // 
            this.c10.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.c10.FlatAppearance.BorderSize = 0;
            this.c10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.c10.Location = new System.Drawing.Point(79, 260);
            this.c10.Name = "c10";
            this.c10.Size = new System.Drawing.Size(20, 20);
            this.c10.TabIndex = 29;
            this.c10.UseVisualStyleBackColor = false;
            // 
            // c9
            // 
            this.c9.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.c9.FlatAppearance.BorderSize = 0;
            this.c9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.c9.Location = new System.Drawing.Point(79, 234);
            this.c9.Name = "c9";
            this.c9.Size = new System.Drawing.Size(20, 20);
            this.c9.TabIndex = 28;
            this.c9.UseVisualStyleBackColor = false;
            // 
            // c8
            // 
            this.c8.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.c8.FlatAppearance.BorderSize = 0;
            this.c8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.c8.Location = new System.Drawing.Point(79, 208);
            this.c8.Name = "c8";
            this.c8.Size = new System.Drawing.Size(20, 20);
            this.c8.TabIndex = 27;
            this.c8.UseVisualStyleBackColor = false;
            // 
            // c7
            // 
            this.c7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.c7.FlatAppearance.BorderSize = 0;
            this.c7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.c7.Location = new System.Drawing.Point(79, 182);
            this.c7.Name = "c7";
            this.c7.Size = new System.Drawing.Size(20, 20);
            this.c7.TabIndex = 26;
            this.c7.UseVisualStyleBackColor = false;
            // 
            // c6
            // 
            this.c6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.c6.FlatAppearance.BorderSize = 0;
            this.c6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.c6.Location = new System.Drawing.Point(79, 156);
            this.c6.Name = "c6";
            this.c6.Size = new System.Drawing.Size(20, 20);
            this.c6.TabIndex = 25;
            this.c6.UseVisualStyleBackColor = false;
            // 
            // c5
            // 
            this.c5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.c5.FlatAppearance.BorderSize = 0;
            this.c5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.c5.Location = new System.Drawing.Point(79, 130);
            this.c5.Name = "c5";
            this.c5.Size = new System.Drawing.Size(20, 20);
            this.c5.TabIndex = 24;
            this.c5.UseVisualStyleBackColor = false;
            // 
            // c4
            // 
            this.c4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.c4.FlatAppearance.BorderSize = 0;
            this.c4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.c4.Location = new System.Drawing.Point(79, 104);
            this.c4.Name = "c4";
            this.c4.Size = new System.Drawing.Size(20, 20);
            this.c4.TabIndex = 23;
            this.c4.UseVisualStyleBackColor = false;
            // 
            // c3
            // 
            this.c3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.c3.FlatAppearance.BorderSize = 0;
            this.c3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.c3.Location = new System.Drawing.Point(79, 78);
            this.c3.Name = "c3";
            this.c3.Size = new System.Drawing.Size(20, 20);
            this.c3.TabIndex = 22;
            this.c3.UseVisualStyleBackColor = false;
            // 
            // c2
            // 
            this.c2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.c2.FlatAppearance.BorderSize = 0;
            this.c2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.c2.Location = new System.Drawing.Point(79, 52);
            this.c2.Name = "c2";
            this.c2.Size = new System.Drawing.Size(20, 20);
            this.c2.TabIndex = 21;
            this.c2.UseVisualStyleBackColor = false;
            // 
            // c1
            // 
            this.c1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.c1.FlatAppearance.BorderSize = 0;
            this.c1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.c1.Location = new System.Drawing.Point(79, 26);
            this.c1.Name = "c1";
            this.c1.Size = new System.Drawing.Size(20, 20);
            this.c1.TabIndex = 20;
            this.c1.UseVisualStyleBackColor = false;
            // 
            // b10
            // 
            this.b10.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.b10.FlatAppearance.BorderSize = 0;
            this.b10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b10.Location = new System.Drawing.Point(53, 260);
            this.b10.Name = "b10";
            this.b10.Size = new System.Drawing.Size(20, 20);
            this.b10.TabIndex = 19;
            this.b10.UseVisualStyleBackColor = false;
            // 
            // b9
            // 
            this.b9.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.b9.FlatAppearance.BorderSize = 0;
            this.b9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b9.Location = new System.Drawing.Point(53, 234);
            this.b9.Name = "b9";
            this.b9.Size = new System.Drawing.Size(20, 20);
            this.b9.TabIndex = 18;
            this.b9.UseVisualStyleBackColor = false;
            // 
            // bb8
            // 
            this.bb8.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.bb8.FlatAppearance.BorderSize = 0;
            this.bb8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bb8.Location = new System.Drawing.Point(53, 208);
            this.bb8.Name = "bb8";
            this.bb8.Size = new System.Drawing.Size(20, 20);
            this.bb8.TabIndex = 17;
            this.bb8.UseVisualStyleBackColor = false;
            // 
            // b7
            // 
            this.b7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.b7.FlatAppearance.BorderSize = 0;
            this.b7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b7.Location = new System.Drawing.Point(53, 182);
            this.b7.Name = "b7";
            this.b7.Size = new System.Drawing.Size(20, 20);
            this.b7.TabIndex = 16;
            this.b7.UseVisualStyleBackColor = false;
            // 
            // b6
            // 
            this.b6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.b6.FlatAppearance.BorderSize = 0;
            this.b6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b6.Location = new System.Drawing.Point(53, 156);
            this.b6.Name = "b6";
            this.b6.Size = new System.Drawing.Size(20, 20);
            this.b6.TabIndex = 15;
            this.b6.UseVisualStyleBackColor = false;
            // 
            // b5
            // 
            this.b5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.b5.FlatAppearance.BorderSize = 0;
            this.b5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b5.Location = new System.Drawing.Point(53, 130);
            this.b5.Name = "b5";
            this.b5.Size = new System.Drawing.Size(20, 20);
            this.b5.TabIndex = 14;
            this.b5.UseVisualStyleBackColor = false;
            // 
            // b4
            // 
            this.b4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.b4.FlatAppearance.BorderSize = 0;
            this.b4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b4.Location = new System.Drawing.Point(53, 104);
            this.b4.Name = "b4";
            this.b4.Size = new System.Drawing.Size(20, 20);
            this.b4.TabIndex = 13;
            this.b4.UseVisualStyleBackColor = false;
            // 
            // b3
            // 
            this.b3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.b3.FlatAppearance.BorderSize = 0;
            this.b3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b3.Location = new System.Drawing.Point(53, 78);
            this.b3.Name = "b3";
            this.b3.Size = new System.Drawing.Size(20, 20);
            this.b3.TabIndex = 12;
            this.b3.UseVisualStyleBackColor = false;
            // 
            // b2
            // 
            this.b2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.b2.FlatAppearance.BorderSize = 0;
            this.b2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b2.Location = new System.Drawing.Point(53, 52);
            this.b2.Name = "b2";
            this.b2.Size = new System.Drawing.Size(20, 20);
            this.b2.TabIndex = 11;
            this.b2.UseVisualStyleBackColor = false;
            // 
            // b1
            // 
            this.b1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.b1.FlatAppearance.BorderSize = 0;
            this.b1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b1.Location = new System.Drawing.Point(53, 26);
            this.b1.Name = "b1";
            this.b1.Size = new System.Drawing.Size(20, 20);
            this.b1.TabIndex = 10;
            this.b1.UseVisualStyleBackColor = false;
            // 
            // a10
            // 
            this.a10.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.a10.FlatAppearance.BorderSize = 0;
            this.a10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.a10.Location = new System.Drawing.Point(27, 260);
            this.a10.Name = "a10";
            this.a10.Size = new System.Drawing.Size(20, 20);
            this.a10.TabIndex = 9;
            this.a10.UseVisualStyleBackColor = false;
            // 
            // a9
            // 
            this.a9.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.a9.FlatAppearance.BorderSize = 0;
            this.a9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.a9.Location = new System.Drawing.Point(27, 234);
            this.a9.Name = "a9";
            this.a9.Size = new System.Drawing.Size(20, 20);
            this.a9.TabIndex = 8;
            this.a9.UseVisualStyleBackColor = false;
            // 
            // a8
            // 
            this.a8.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.a8.FlatAppearance.BorderSize = 0;
            this.a8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.a8.Location = new System.Drawing.Point(27, 208);
            this.a8.Name = "a8";
            this.a8.Size = new System.Drawing.Size(20, 20);
            this.a8.TabIndex = 7;
            this.a8.UseVisualStyleBackColor = false;
            // 
            // a7
            // 
            this.a7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.a7.FlatAppearance.BorderSize = 0;
            this.a7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.a7.Location = new System.Drawing.Point(27, 182);
            this.a7.Name = "a7";
            this.a7.Size = new System.Drawing.Size(20, 20);
            this.a7.TabIndex = 6;
            this.a7.UseVisualStyleBackColor = false;
            // 
            // a6
            // 
            this.a6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.a6.FlatAppearance.BorderSize = 0;
            this.a6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.a6.Location = new System.Drawing.Point(27, 156);
            this.a6.Name = "a6";
            this.a6.Size = new System.Drawing.Size(20, 20);
            this.a6.TabIndex = 5;
            this.a6.UseVisualStyleBackColor = false;
            // 
            // a5
            // 
            this.a5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.a5.FlatAppearance.BorderSize = 0;
            this.a5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.a5.Location = new System.Drawing.Point(27, 130);
            this.a5.Name = "a5";
            this.a5.Size = new System.Drawing.Size(20, 20);
            this.a5.TabIndex = 4;
            this.a5.UseVisualStyleBackColor = false;
            // 
            // a4
            // 
            this.a4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.a4.FlatAppearance.BorderSize = 0;
            this.a4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.a4.Location = new System.Drawing.Point(27, 104);
            this.a4.Name = "a4";
            this.a4.Size = new System.Drawing.Size(20, 20);
            this.a4.TabIndex = 3;
            this.a4.UseVisualStyleBackColor = false;
            // 
            // a3
            // 
            this.a3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.a3.FlatAppearance.BorderSize = 0;
            this.a3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.a3.Location = new System.Drawing.Point(27, 78);
            this.a3.Name = "a3";
            this.a3.Size = new System.Drawing.Size(20, 20);
            this.a3.TabIndex = 2;
            this.a3.UseVisualStyleBackColor = false;
            // 
            // a2
            // 
            this.a2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.a2.FlatAppearance.BorderSize = 0;
            this.a2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.a2.Location = new System.Drawing.Point(27, 52);
            this.a2.Name = "a2";
            this.a2.Size = new System.Drawing.Size(20, 20);
            this.a2.TabIndex = 1;
            this.a2.UseVisualStyleBackColor = false;
            // 
            // a1
            // 
            this.a1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.a1.FlatAppearance.BorderSize = 0;
            this.a1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.a1.Location = new System.Drawing.Point(27, 26);
            this.a1.Name = "a1";
            this.a1.Size = new System.Drawing.Size(20, 20);
            this.a1.TabIndex = 0;
            this.a1.UseVisualStyleBackColor = false;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Arial Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label21.Location = new System.Drawing.Point(-2, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(111, 23);
            this.label21.TabIndex = 2;
            this.label21.Text = "Your Boats:";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::BattleShipForms.Properties.Resources.Boat2Big;
            this.pictureBox1.Location = new System.Drawing.Point(0, 30);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(71, 70);
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label22.Location = new System.Drawing.Point(77, 56);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(56, 19);
            this.label22.TabIndex = 4;
            this.label22.Text = "Size : ";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label23.Location = new System.Drawing.Point(77, 81);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(70, 19);
            this.label23.TabIndex = 5;
            this.label23.Text = "Count : ";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label24.Location = new System.Drawing.Point(132, 56);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(77, 18);
            this.label24.TabIndex = 6;
            this.label24.Text = "2 squares";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label25.Location = new System.Drawing.Point(140, 82);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(21, 18);
            this.label25.TabIndex = 7;
            this.label25.Text = "2 ";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel3.Controls.Add(this.label40);
            this.panel3.Controls.Add(this.label41);
            this.panel3.Controls.Add(this.pictureBox4);
            this.panel3.Controls.Add(this.label42);
            this.panel3.Controls.Add(this.label43);
            this.panel3.Controls.Add(this.label44);
            this.panel3.Controls.Add(this.label45);
            this.panel3.Controls.Add(this.label34);
            this.panel3.Controls.Add(this.label35);
            this.panel3.Controls.Add(this.pictureBox3);
            this.panel3.Controls.Add(this.label36);
            this.panel3.Controls.Add(this.label37);
            this.panel3.Controls.Add(this.label38);
            this.panel3.Controls.Add(this.label39);
            this.panel3.Controls.Add(this.label28);
            this.panel3.Controls.Add(this.label29);
            this.panel3.Controls.Add(this.pictureBox2);
            this.panel3.Controls.Add(this.label30);
            this.panel3.Controls.Add(this.label31);
            this.panel3.Controls.Add(this.label32);
            this.panel3.Controls.Add(this.label33);
            this.panel3.Controls.Add(this.label26);
            this.panel3.Controls.Add(this.label27);
            this.panel3.Controls.Add(this.pictureBox1);
            this.panel3.Controls.Add(this.label25);
            this.panel3.Controls.Add(this.label21);
            this.panel3.Controls.Add(this.label24);
            this.panel3.Controls.Add(this.label22);
            this.panel3.Controls.Add(this.label23);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(0, 410);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(782, 183);
            this.panel3.TabIndex = 8;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label40.Location = new System.Drawing.Point(135, 106);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(80, 18);
            this.label40.TabIndex = 30;
            this.label40.Text = "BattleShip";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label41.Location = new System.Drawing.Point(80, 106);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(67, 19);
            this.label41.TabIndex = 29;
            this.label41.Text = "Name : ";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::BattleShipForms.Properties.Resources.Boat4Big;
            this.pictureBox4.Location = new System.Drawing.Point(0, 106);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(71, 70);
            this.pictureBox4.TabIndex = 24;
            this.pictureBox4.TabStop = false;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label42.Location = new System.Drawing.Point(140, 158);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(17, 18);
            this.label42.TabIndex = 28;
            this.label42.Text = "1";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label43.Location = new System.Drawing.Point(132, 132);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(77, 18);
            this.label43.TabIndex = 27;
            this.label43.Text = "4 squares";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label44.Location = new System.Drawing.Point(77, 132);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(56, 19);
            this.label44.TabIndex = 25;
            this.label44.Text = "Size : ";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label45.Location = new System.Drawing.Point(77, 157);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(70, 19);
            this.label45.TabIndex = 26;
            this.label45.Text = "Count : ";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label34.Location = new System.Drawing.Point(347, 106);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(59, 18);
            this.label34.TabIndex = 23;
            this.label34.Text = "Cruiser";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label35.Location = new System.Drawing.Point(292, 106);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(67, 19);
            this.label35.TabIndex = 22;
            this.label35.Text = "Name : ";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::BattleShipForms.Properties.Resources.Boat5Big;
            this.pictureBox3.Location = new System.Drawing.Point(212, 106);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(71, 70);
            this.pictureBox3.TabIndex = 17;
            this.pictureBox3.TabStop = false;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label36.Location = new System.Drawing.Point(352, 158);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(17, 18);
            this.label36.TabIndex = 21;
            this.label36.Text = "1";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label37.Location = new System.Drawing.Point(344, 132);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(77, 18);
            this.label37.TabIndex = 20;
            this.label37.Text = "5 squares";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label38.Location = new System.Drawing.Point(289, 132);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(56, 19);
            this.label38.TabIndex = 18;
            this.label38.Text = "Size : ";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label39.Location = new System.Drawing.Point(289, 157);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(70, 19);
            this.label39.TabIndex = 19;
            this.label39.Text = "Count : ";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label28.Location = new System.Drawing.Point(347, 30);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(76, 18);
            this.label28.TabIndex = 16;
            this.label28.Text = "Destroyer";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label29.Location = new System.Drawing.Point(292, 30);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(67, 19);
            this.label29.TabIndex = 15;
            this.label29.Text = "Name : ";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::BattleShipForms.Properties.Resources.Boat3Big;
            this.pictureBox2.Location = new System.Drawing.Point(212, 30);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(71, 70);
            this.pictureBox2.TabIndex = 10;
            this.pictureBox2.TabStop = false;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label30.Location = new System.Drawing.Point(352, 82);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(17, 18);
            this.label30.TabIndex = 14;
            this.label30.Text = "1";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label31.Location = new System.Drawing.Point(344, 56);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(77, 18);
            this.label31.TabIndex = 13;
            this.label31.Text = "3 squares";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label32.Location = new System.Drawing.Point(289, 56);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(56, 19);
            this.label32.TabIndex = 11;
            this.label32.Text = "Size : ";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label33.Location = new System.Drawing.Point(289, 81);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(70, 19);
            this.label33.TabIndex = 12;
            this.label33.Text = "Count : ";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label26.Location = new System.Drawing.Point(135, 30);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(80, 18);
            this.label26.TabIndex = 9;
            this.label26.Text = "Small ship";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label27.Location = new System.Drawing.Point(80, 30);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(67, 19);
            this.label27.TabIndex = 8;
            this.label27.Text = "Name : ";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label52.Location = new System.Drawing.Point(93, 94);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(116, 22);
            this.label52.TabIndex = 6;
            this.label52.Text = "Your Board";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label53.Location = new System.Drawing.Point(498, 94);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(180, 22);
            this.label53.TabIndex = 10;
            this.label53.Text = "Opponent\'s Board";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.label54);
            this.panel4.Controls.Add(this.label55);
            this.panel4.Controls.Add(this.label56);
            this.panel4.Controls.Add(this.label57);
            this.panel4.Controls.Add(this.label58);
            this.panel4.Controls.Add(this.label59);
            this.panel4.Controls.Add(this.label60);
            this.panel4.Controls.Add(this.label61);
            this.panel4.Controls.Add(this.label62);
            this.panel4.Controls.Add(this.label63);
            this.panel4.Controls.Add(this.label64);
            this.panel4.Controls.Add(this.label65);
            this.panel4.Controls.Add(this.label66);
            this.panel4.Controls.Add(this.label67);
            this.panel4.Controls.Add(this.label68);
            this.panel4.Controls.Add(this.label69);
            this.panel4.Controls.Add(this.label70);
            this.panel4.Controls.Add(this.label71);
            this.panel4.Controls.Add(this.label72);
            this.panel4.Controls.Add(this.label73);
            this.panel4.Controls.Add(this.button1);
            this.panel4.Controls.Add(this.button2);
            this.panel4.Controls.Add(this.button3);
            this.panel4.Controls.Add(this.button4);
            this.panel4.Controls.Add(this.button5);
            this.panel4.Controls.Add(this.button6);
            this.panel4.Controls.Add(this.button7);
            this.panel4.Controls.Add(this.button8);
            this.panel4.Controls.Add(this.button9);
            this.panel4.Controls.Add(this.button10);
            this.panel4.Controls.Add(this.button11);
            this.panel4.Controls.Add(this.button12);
            this.panel4.Controls.Add(this.button13);
            this.panel4.Controls.Add(this.button14);
            this.panel4.Controls.Add(this.button15);
            this.panel4.Controls.Add(this.button16);
            this.panel4.Controls.Add(this.button17);
            this.panel4.Controls.Add(this.button18);
            this.panel4.Controls.Add(this.button19);
            this.panel4.Controls.Add(this.button20);
            this.panel4.Controls.Add(this.button21);
            this.panel4.Controls.Add(this.button22);
            this.panel4.Controls.Add(this.button23);
            this.panel4.Controls.Add(this.button24);
            this.panel4.Controls.Add(this.button25);
            this.panel4.Controls.Add(this.button26);
            this.panel4.Controls.Add(this.button27);
            this.panel4.Controls.Add(this.button28);
            this.panel4.Controls.Add(this.button29);
            this.panel4.Controls.Add(this.button30);
            this.panel4.Controls.Add(this.button31);
            this.panel4.Controls.Add(this.button32);
            this.panel4.Controls.Add(this.button33);
            this.panel4.Controls.Add(this.button34);
            this.panel4.Controls.Add(this.button35);
            this.panel4.Controls.Add(this.button36);
            this.panel4.Controls.Add(this.button37);
            this.panel4.Controls.Add(this.button38);
            this.panel4.Controls.Add(this.button39);
            this.panel4.Controls.Add(this.button40);
            this.panel4.Controls.Add(this.button41);
            this.panel4.Controls.Add(this.button42);
            this.panel4.Controls.Add(this.button43);
            this.panel4.Controls.Add(this.button44);
            this.panel4.Controls.Add(this.button45);
            this.panel4.Controls.Add(this.button46);
            this.panel4.Controls.Add(this.button47);
            this.panel4.Controls.Add(this.button48);
            this.panel4.Controls.Add(this.button49);
            this.panel4.Controls.Add(this.button50);
            this.panel4.Controls.Add(this.button51);
            this.panel4.Controls.Add(this.button52);
            this.panel4.Controls.Add(this.button53);
            this.panel4.Controls.Add(this.button54);
            this.panel4.Controls.Add(this.button55);
            this.panel4.Controls.Add(this.button56);
            this.panel4.Controls.Add(this.button57);
            this.panel4.Controls.Add(this.button58);
            this.panel4.Controls.Add(this.button59);
            this.panel4.Controls.Add(this.button60);
            this.panel4.Controls.Add(this.button61);
            this.panel4.Controls.Add(this.button62);
            this.panel4.Controls.Add(this.button63);
            this.panel4.Controls.Add(this.button64);
            this.panel4.Controls.Add(this.button65);
            this.panel4.Controls.Add(this.button66);
            this.panel4.Controls.Add(this.button67);
            this.panel4.Controls.Add(this.button68);
            this.panel4.Controls.Add(this.button69);
            this.panel4.Controls.Add(this.button70);
            this.panel4.Controls.Add(this.button71);
            this.panel4.Controls.Add(this.button72);
            this.panel4.Controls.Add(this.button73);
            this.panel4.Controls.Add(this.button74);
            this.panel4.Controls.Add(this.button75);
            this.panel4.Controls.Add(this.button76);
            this.panel4.Controls.Add(this.button77);
            this.panel4.Controls.Add(this.button78);
            this.panel4.Controls.Add(this.button79);
            this.panel4.Controls.Add(this.button80);
            this.panel4.Controls.Add(this.button81);
            this.panel4.Controls.Add(this.button82);
            this.panel4.Controls.Add(this.button83);
            this.panel4.Controls.Add(this.button84);
            this.panel4.Controls.Add(this.button85);
            this.panel4.Controls.Add(this.button86);
            this.panel4.Controls.Add(this.button87);
            this.panel4.Controls.Add(this.button88);
            this.panel4.Controls.Add(this.button89);
            this.panel4.Controls.Add(this.button90);
            this.panel4.Controls.Add(this.button91);
            this.panel4.Controls.Add(this.button92);
            this.panel4.Controls.Add(this.button93);
            this.panel4.Controls.Add(this.button94);
            this.panel4.Controls.Add(this.button95);
            this.panel4.Controls.Add(this.button96);
            this.panel4.Controls.Add(this.button97);
            this.panel4.Controls.Add(this.button98);
            this.panel4.Controls.Add(this.button99);
            this.panel4.Controls.Add(this.button100);
            this.panel4.Location = new System.Drawing.Point(445, 119);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(288, 285);
            this.panel4.TabIndex = 9;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label54.Location = new System.Drawing.Point(261, 3);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(16, 20);
            this.label54.TabIndex = 119;
            this.label54.Text = "J";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label55.Location = new System.Drawing.Point(235, 3);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(13, 20);
            this.label55.TabIndex = 118;
            this.label55.Text = "I";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label56.Location = new System.Drawing.Point(209, 3);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(18, 20);
            this.label56.TabIndex = 117;
            this.label56.Text = "H";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label57.Location = new System.Drawing.Point(183, 3);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(19, 20);
            this.label57.TabIndex = 116;
            this.label57.Text = "G";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label58.Location = new System.Drawing.Point(157, 3);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(17, 20);
            this.label58.TabIndex = 115;
            this.label58.Text = "F";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label59.Location = new System.Drawing.Point(131, 3);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(18, 20);
            this.label59.TabIndex = 114;
            this.label59.Text = "E";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label60.Location = new System.Drawing.Point(105, 3);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(18, 20);
            this.label60.TabIndex = 113;
            this.label60.Text = "D";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label61.Location = new System.Drawing.Point(79, 3);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(18, 20);
            this.label61.TabIndex = 112;
            this.label61.Text = "C";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label62.Location = new System.Drawing.Point(53, 3);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(18, 20);
            this.label62.TabIndex = 111;
            this.label62.Text = "B";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label63.Location = new System.Drawing.Point(27, 3);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(18, 20);
            this.label63.TabIndex = 110;
            this.label63.Text = "A";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label64.Location = new System.Drawing.Point(5, 260);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(23, 20);
            this.label64.TabIndex = 109;
            this.label64.Text = "10";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label65.Location = new System.Drawing.Point(5, 234);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(16, 20);
            this.label65.TabIndex = 108;
            this.label65.Text = "9";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label66.Location = new System.Drawing.Point(5, 208);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(16, 20);
            this.label66.TabIndex = 107;
            this.label66.Text = "8";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label67.Location = new System.Drawing.Point(5, 182);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(16, 20);
            this.label67.TabIndex = 106;
            this.label67.Text = "7";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label68.Location = new System.Drawing.Point(5, 156);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(16, 20);
            this.label68.TabIndex = 105;
            this.label68.Text = "6";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label69.Location = new System.Drawing.Point(5, 130);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(16, 20);
            this.label69.TabIndex = 104;
            this.label69.Text = "5";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label70.Location = new System.Drawing.Point(5, 104);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(16, 20);
            this.label70.TabIndex = 103;
            this.label70.Text = "4";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label71.Location = new System.Drawing.Point(5, 78);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(16, 20);
            this.label71.TabIndex = 102;
            this.label71.Text = "3";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label72.Location = new System.Drawing.Point(5, 52);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(16, 20);
            this.label72.TabIndex = 101;
            this.label72.Text = "2";
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label73.Location = new System.Drawing.Point(5, 26);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(16, 20);
            this.label73.TabIndex = 100;
            this.label73.Text = "1";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(261, 260);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(20, 20);
            this.button1.TabIndex = 99;
            this.button1.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Location = new System.Drawing.Point(261, 234);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(20, 20);
            this.button2.TabIndex = 98;
            this.button2.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Location = new System.Drawing.Point(261, 208);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(20, 20);
            this.button3.TabIndex = 97;
            this.button3.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Location = new System.Drawing.Point(261, 182);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(20, 20);
            this.button4.TabIndex = 96;
            this.button4.UseVisualStyleBackColor = false;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Location = new System.Drawing.Point(261, 156);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(20, 20);
            this.button5.TabIndex = 95;
            this.button5.UseVisualStyleBackColor = false;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button6.FlatAppearance.BorderSize = 0;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Location = new System.Drawing.Point(261, 130);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(20, 20);
            this.button6.TabIndex = 94;
            this.button6.UseVisualStyleBackColor = false;
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button7.FlatAppearance.BorderSize = 0;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Location = new System.Drawing.Point(261, 104);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(20, 20);
            this.button7.TabIndex = 93;
            this.button7.UseVisualStyleBackColor = false;
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button8.FlatAppearance.BorderSize = 0;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Location = new System.Drawing.Point(261, 78);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(20, 20);
            this.button8.TabIndex = 92;
            this.button8.UseVisualStyleBackColor = false;
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button9.FlatAppearance.BorderSize = 0;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Location = new System.Drawing.Point(261, 52);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(20, 20);
            this.button9.TabIndex = 91;
            this.button9.UseVisualStyleBackColor = false;
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button10.FlatAppearance.BorderSize = 0;
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.Location = new System.Drawing.Point(261, 26);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(20, 20);
            this.button10.TabIndex = 90;
            this.button10.UseVisualStyleBackColor = false;
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button11.FlatAppearance.BorderSize = 0;
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button11.Location = new System.Drawing.Point(235, 260);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(20, 20);
            this.button11.TabIndex = 89;
            this.button11.UseVisualStyleBackColor = false;
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button12.FlatAppearance.BorderSize = 0;
            this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button12.Location = new System.Drawing.Point(235, 234);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(20, 20);
            this.button12.TabIndex = 88;
            this.button12.UseVisualStyleBackColor = false;
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button13.FlatAppearance.BorderSize = 0;
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button13.Location = new System.Drawing.Point(235, 208);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(20, 20);
            this.button13.TabIndex = 87;
            this.button13.UseVisualStyleBackColor = false;
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button14.FlatAppearance.BorderSize = 0;
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button14.Location = new System.Drawing.Point(235, 182);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(20, 20);
            this.button14.TabIndex = 86;
            this.button14.UseVisualStyleBackColor = false;
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button15.FlatAppearance.BorderSize = 0;
            this.button15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button15.Location = new System.Drawing.Point(235, 156);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(20, 20);
            this.button15.TabIndex = 85;
            this.button15.UseVisualStyleBackColor = false;
            // 
            // button16
            // 
            this.button16.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button16.FlatAppearance.BorderSize = 0;
            this.button16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button16.Location = new System.Drawing.Point(235, 130);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(20, 20);
            this.button16.TabIndex = 84;
            this.button16.UseVisualStyleBackColor = false;
            // 
            // button17
            // 
            this.button17.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button17.FlatAppearance.BorderSize = 0;
            this.button17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button17.Location = new System.Drawing.Point(235, 104);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(20, 20);
            this.button17.TabIndex = 83;
            this.button17.UseVisualStyleBackColor = false;
            // 
            // button18
            // 
            this.button18.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button18.FlatAppearance.BorderSize = 0;
            this.button18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button18.Location = new System.Drawing.Point(235, 78);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(20, 20);
            this.button18.TabIndex = 82;
            this.button18.UseVisualStyleBackColor = false;
            // 
            // button19
            // 
            this.button19.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button19.FlatAppearance.BorderSize = 0;
            this.button19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button19.Location = new System.Drawing.Point(235, 52);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(20, 20);
            this.button19.TabIndex = 81;
            this.button19.UseVisualStyleBackColor = false;
            // 
            // button20
            // 
            this.button20.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button20.FlatAppearance.BorderSize = 0;
            this.button20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button20.Location = new System.Drawing.Point(235, 26);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(20, 20);
            this.button20.TabIndex = 80;
            this.button20.UseVisualStyleBackColor = false;
            // 
            // button21
            // 
            this.button21.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button21.FlatAppearance.BorderSize = 0;
            this.button21.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button21.Location = new System.Drawing.Point(209, 260);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(20, 20);
            this.button21.TabIndex = 79;
            this.button21.UseVisualStyleBackColor = false;
            // 
            // button22
            // 
            this.button22.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button22.FlatAppearance.BorderSize = 0;
            this.button22.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button22.Location = new System.Drawing.Point(209, 234);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(20, 20);
            this.button22.TabIndex = 78;
            this.button22.UseVisualStyleBackColor = false;
            // 
            // button23
            // 
            this.button23.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button23.FlatAppearance.BorderSize = 0;
            this.button23.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button23.Location = new System.Drawing.Point(209, 208);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(20, 20);
            this.button23.TabIndex = 77;
            this.button23.UseVisualStyleBackColor = false;
            // 
            // button24
            // 
            this.button24.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button24.FlatAppearance.BorderSize = 0;
            this.button24.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button24.Location = new System.Drawing.Point(209, 182);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(20, 20);
            this.button24.TabIndex = 76;
            this.button24.UseVisualStyleBackColor = false;
            // 
            // button25
            // 
            this.button25.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button25.FlatAppearance.BorderSize = 0;
            this.button25.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button25.Location = new System.Drawing.Point(209, 156);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(20, 20);
            this.button25.TabIndex = 75;
            this.button25.UseVisualStyleBackColor = false;
            // 
            // button26
            // 
            this.button26.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button26.FlatAppearance.BorderSize = 0;
            this.button26.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button26.Location = new System.Drawing.Point(209, 130);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(20, 20);
            this.button26.TabIndex = 74;
            this.button26.UseVisualStyleBackColor = false;
            // 
            // button27
            // 
            this.button27.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button27.FlatAppearance.BorderSize = 0;
            this.button27.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button27.Location = new System.Drawing.Point(209, 104);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(20, 20);
            this.button27.TabIndex = 73;
            this.button27.UseVisualStyleBackColor = false;
            // 
            // button28
            // 
            this.button28.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button28.FlatAppearance.BorderSize = 0;
            this.button28.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button28.Location = new System.Drawing.Point(209, 78);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(20, 20);
            this.button28.TabIndex = 72;
            this.button28.UseVisualStyleBackColor = false;
            // 
            // button29
            // 
            this.button29.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button29.FlatAppearance.BorderSize = 0;
            this.button29.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button29.Location = new System.Drawing.Point(209, 52);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(20, 20);
            this.button29.TabIndex = 71;
            this.button29.UseVisualStyleBackColor = false;
            // 
            // button30
            // 
            this.button30.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button30.FlatAppearance.BorderSize = 0;
            this.button30.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button30.Location = new System.Drawing.Point(209, 26);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(20, 20);
            this.button30.TabIndex = 70;
            this.button30.UseVisualStyleBackColor = false;
            // 
            // button31
            // 
            this.button31.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button31.FlatAppearance.BorderSize = 0;
            this.button31.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button31.Location = new System.Drawing.Point(183, 260);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(20, 20);
            this.button31.TabIndex = 69;
            this.button31.UseVisualStyleBackColor = false;
            // 
            // button32
            // 
            this.button32.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button32.FlatAppearance.BorderSize = 0;
            this.button32.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button32.Location = new System.Drawing.Point(183, 234);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(20, 20);
            this.button32.TabIndex = 68;
            this.button32.UseVisualStyleBackColor = false;
            // 
            // button33
            // 
            this.button33.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button33.FlatAppearance.BorderSize = 0;
            this.button33.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button33.Location = new System.Drawing.Point(183, 208);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(20, 20);
            this.button33.TabIndex = 67;
            this.button33.UseVisualStyleBackColor = false;
            // 
            // button34
            // 
            this.button34.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button34.FlatAppearance.BorderSize = 0;
            this.button34.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button34.Location = new System.Drawing.Point(183, 182);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(20, 20);
            this.button34.TabIndex = 66;
            this.button34.UseVisualStyleBackColor = false;
            // 
            // button35
            // 
            this.button35.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button35.FlatAppearance.BorderSize = 0;
            this.button35.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button35.Location = new System.Drawing.Point(183, 156);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(20, 20);
            this.button35.TabIndex = 65;
            this.button35.UseVisualStyleBackColor = false;
            // 
            // button36
            // 
            this.button36.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button36.FlatAppearance.BorderSize = 0;
            this.button36.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button36.Location = new System.Drawing.Point(183, 130);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(20, 20);
            this.button36.TabIndex = 64;
            this.button36.UseVisualStyleBackColor = false;
            // 
            // button37
            // 
            this.button37.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button37.FlatAppearance.BorderSize = 0;
            this.button37.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button37.Location = new System.Drawing.Point(183, 104);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(20, 20);
            this.button37.TabIndex = 63;
            this.button37.UseVisualStyleBackColor = false;
            // 
            // button38
            // 
            this.button38.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button38.FlatAppearance.BorderSize = 0;
            this.button38.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button38.Location = new System.Drawing.Point(183, 78);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(20, 20);
            this.button38.TabIndex = 62;
            this.button38.UseVisualStyleBackColor = false;
            // 
            // button39
            // 
            this.button39.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button39.FlatAppearance.BorderSize = 0;
            this.button39.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button39.Location = new System.Drawing.Point(183, 52);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(20, 20);
            this.button39.TabIndex = 61;
            this.button39.UseVisualStyleBackColor = false;
            // 
            // button40
            // 
            this.button40.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button40.FlatAppearance.BorderSize = 0;
            this.button40.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button40.Location = new System.Drawing.Point(183, 26);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(20, 20);
            this.button40.TabIndex = 60;
            this.button40.UseVisualStyleBackColor = false;
            // 
            // button41
            // 
            this.button41.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button41.FlatAppearance.BorderSize = 0;
            this.button41.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button41.Location = new System.Drawing.Point(157, 260);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(20, 20);
            this.button41.TabIndex = 59;
            this.button41.UseVisualStyleBackColor = false;
            // 
            // button42
            // 
            this.button42.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button42.FlatAppearance.BorderSize = 0;
            this.button42.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button42.Location = new System.Drawing.Point(157, 234);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(20, 20);
            this.button42.TabIndex = 58;
            this.button42.UseVisualStyleBackColor = false;
            // 
            // button43
            // 
            this.button43.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button43.FlatAppearance.BorderSize = 0;
            this.button43.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button43.Location = new System.Drawing.Point(157, 208);
            this.button43.Name = "button43";
            this.button43.Size = new System.Drawing.Size(20, 20);
            this.button43.TabIndex = 57;
            this.button43.UseVisualStyleBackColor = false;
            // 
            // button44
            // 
            this.button44.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button44.FlatAppearance.BorderSize = 0;
            this.button44.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button44.Location = new System.Drawing.Point(157, 182);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(20, 20);
            this.button44.TabIndex = 56;
            this.button44.UseVisualStyleBackColor = false;
            // 
            // button45
            // 
            this.button45.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button45.FlatAppearance.BorderSize = 0;
            this.button45.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button45.Location = new System.Drawing.Point(157, 156);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(20, 20);
            this.button45.TabIndex = 55;
            this.button45.UseVisualStyleBackColor = false;
            // 
            // button46
            // 
            this.button46.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button46.FlatAppearance.BorderSize = 0;
            this.button46.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button46.Location = new System.Drawing.Point(157, 130);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(20, 20);
            this.button46.TabIndex = 54;
            this.button46.UseVisualStyleBackColor = false;
            // 
            // button47
            // 
            this.button47.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button47.FlatAppearance.BorderSize = 0;
            this.button47.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button47.Location = new System.Drawing.Point(157, 104);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(20, 20);
            this.button47.TabIndex = 53;
            this.button47.UseVisualStyleBackColor = false;
            // 
            // button48
            // 
            this.button48.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button48.FlatAppearance.BorderSize = 0;
            this.button48.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button48.Location = new System.Drawing.Point(157, 78);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(20, 20);
            this.button48.TabIndex = 52;
            this.button48.UseVisualStyleBackColor = false;
            // 
            // button49
            // 
            this.button49.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button49.FlatAppearance.BorderSize = 0;
            this.button49.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button49.Location = new System.Drawing.Point(157, 52);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(20, 20);
            this.button49.TabIndex = 51;
            this.button49.UseVisualStyleBackColor = false;
            // 
            // button50
            // 
            this.button50.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button50.FlatAppearance.BorderSize = 0;
            this.button50.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button50.Location = new System.Drawing.Point(157, 26);
            this.button50.Name = "button50";
            this.button50.Size = new System.Drawing.Size(20, 20);
            this.button50.TabIndex = 50;
            this.button50.UseVisualStyleBackColor = false;
            // 
            // button51
            // 
            this.button51.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button51.FlatAppearance.BorderSize = 0;
            this.button51.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button51.Location = new System.Drawing.Point(131, 260);
            this.button51.Name = "button51";
            this.button51.Size = new System.Drawing.Size(20, 20);
            this.button51.TabIndex = 49;
            this.button51.UseVisualStyleBackColor = false;
            // 
            // button52
            // 
            this.button52.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button52.FlatAppearance.BorderSize = 0;
            this.button52.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button52.Location = new System.Drawing.Point(131, 234);
            this.button52.Name = "button52";
            this.button52.Size = new System.Drawing.Size(20, 20);
            this.button52.TabIndex = 48;
            this.button52.UseVisualStyleBackColor = false;
            // 
            // button53
            // 
            this.button53.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button53.FlatAppearance.BorderSize = 0;
            this.button53.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button53.Location = new System.Drawing.Point(131, 208);
            this.button53.Name = "button53";
            this.button53.Size = new System.Drawing.Size(20, 20);
            this.button53.TabIndex = 47;
            this.button53.UseVisualStyleBackColor = false;
            // 
            // button54
            // 
            this.button54.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button54.FlatAppearance.BorderSize = 0;
            this.button54.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button54.Location = new System.Drawing.Point(131, 182);
            this.button54.Name = "button54";
            this.button54.Size = new System.Drawing.Size(20, 20);
            this.button54.TabIndex = 46;
            this.button54.UseVisualStyleBackColor = false;
            // 
            // button55
            // 
            this.button55.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button55.FlatAppearance.BorderSize = 0;
            this.button55.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button55.Location = new System.Drawing.Point(131, 156);
            this.button55.Name = "button55";
            this.button55.Size = new System.Drawing.Size(20, 20);
            this.button55.TabIndex = 45;
            this.button55.UseVisualStyleBackColor = false;
            // 
            // button56
            // 
            this.button56.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button56.FlatAppearance.BorderSize = 0;
            this.button56.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button56.Location = new System.Drawing.Point(131, 130);
            this.button56.Name = "button56";
            this.button56.Size = new System.Drawing.Size(20, 20);
            this.button56.TabIndex = 44;
            this.button56.UseVisualStyleBackColor = false;
            // 
            // button57
            // 
            this.button57.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button57.FlatAppearance.BorderSize = 0;
            this.button57.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button57.Location = new System.Drawing.Point(131, 104);
            this.button57.Name = "button57";
            this.button57.Size = new System.Drawing.Size(20, 20);
            this.button57.TabIndex = 43;
            this.button57.UseVisualStyleBackColor = false;
            // 
            // button58
            // 
            this.button58.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button58.FlatAppearance.BorderSize = 0;
            this.button58.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button58.Location = new System.Drawing.Point(131, 78);
            this.button58.Name = "button58";
            this.button58.Size = new System.Drawing.Size(20, 20);
            this.button58.TabIndex = 42;
            this.button58.UseVisualStyleBackColor = false;
            // 
            // button59
            // 
            this.button59.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button59.FlatAppearance.BorderSize = 0;
            this.button59.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button59.Location = new System.Drawing.Point(131, 52);
            this.button59.Name = "button59";
            this.button59.Size = new System.Drawing.Size(20, 20);
            this.button59.TabIndex = 41;
            this.button59.UseVisualStyleBackColor = false;
            // 
            // button60
            // 
            this.button60.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button60.FlatAppearance.BorderSize = 0;
            this.button60.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button60.Location = new System.Drawing.Point(131, 26);
            this.button60.Name = "button60";
            this.button60.Size = new System.Drawing.Size(20, 20);
            this.button60.TabIndex = 40;
            this.button60.UseVisualStyleBackColor = false;
            // 
            // button61
            // 
            this.button61.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button61.FlatAppearance.BorderSize = 0;
            this.button61.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button61.Location = new System.Drawing.Point(105, 260);
            this.button61.Name = "button61";
            this.button61.Size = new System.Drawing.Size(20, 20);
            this.button61.TabIndex = 39;
            this.button61.UseVisualStyleBackColor = false;
            // 
            // button62
            // 
            this.button62.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button62.FlatAppearance.BorderSize = 0;
            this.button62.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button62.Location = new System.Drawing.Point(105, 234);
            this.button62.Name = "button62";
            this.button62.Size = new System.Drawing.Size(20, 20);
            this.button62.TabIndex = 38;
            this.button62.UseVisualStyleBackColor = false;
            // 
            // button63
            // 
            this.button63.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button63.FlatAppearance.BorderSize = 0;
            this.button63.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button63.Location = new System.Drawing.Point(105, 208);
            this.button63.Name = "button63";
            this.button63.Size = new System.Drawing.Size(20, 20);
            this.button63.TabIndex = 37;
            this.button63.UseVisualStyleBackColor = false;
            // 
            // button64
            // 
            this.button64.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button64.FlatAppearance.BorderSize = 0;
            this.button64.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button64.Location = new System.Drawing.Point(105, 182);
            this.button64.Name = "button64";
            this.button64.Size = new System.Drawing.Size(20, 20);
            this.button64.TabIndex = 36;
            this.button64.UseVisualStyleBackColor = false;
            // 
            // button65
            // 
            this.button65.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button65.FlatAppearance.BorderSize = 0;
            this.button65.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button65.Location = new System.Drawing.Point(105, 156);
            this.button65.Name = "button65";
            this.button65.Size = new System.Drawing.Size(20, 20);
            this.button65.TabIndex = 35;
            this.button65.UseVisualStyleBackColor = false;
            // 
            // button66
            // 
            this.button66.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button66.FlatAppearance.BorderSize = 0;
            this.button66.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button66.Location = new System.Drawing.Point(105, 130);
            this.button66.Name = "button66";
            this.button66.Size = new System.Drawing.Size(20, 20);
            this.button66.TabIndex = 34;
            this.button66.UseVisualStyleBackColor = false;
            // 
            // button67
            // 
            this.button67.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button67.FlatAppearance.BorderSize = 0;
            this.button67.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button67.Location = new System.Drawing.Point(105, 104);
            this.button67.Name = "button67";
            this.button67.Size = new System.Drawing.Size(20, 20);
            this.button67.TabIndex = 33;
            this.button67.UseVisualStyleBackColor = false;
            // 
            // button68
            // 
            this.button68.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button68.FlatAppearance.BorderSize = 0;
            this.button68.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button68.Location = new System.Drawing.Point(105, 78);
            this.button68.Name = "button68";
            this.button68.Size = new System.Drawing.Size(20, 20);
            this.button68.TabIndex = 32;
            this.button68.UseVisualStyleBackColor = false;
            // 
            // button69
            // 
            this.button69.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button69.FlatAppearance.BorderSize = 0;
            this.button69.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button69.Location = new System.Drawing.Point(105, 52);
            this.button69.Name = "button69";
            this.button69.Size = new System.Drawing.Size(20, 20);
            this.button69.TabIndex = 31;
            this.button69.UseVisualStyleBackColor = false;
            // 
            // button70
            // 
            this.button70.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button70.FlatAppearance.BorderSize = 0;
            this.button70.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button70.Location = new System.Drawing.Point(105, 26);
            this.button70.Name = "button70";
            this.button70.Size = new System.Drawing.Size(20, 20);
            this.button70.TabIndex = 30;
            this.button70.UseVisualStyleBackColor = false;
            // 
            // button71
            // 
            this.button71.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button71.FlatAppearance.BorderSize = 0;
            this.button71.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button71.Location = new System.Drawing.Point(79, 260);
            this.button71.Name = "button71";
            this.button71.Size = new System.Drawing.Size(20, 20);
            this.button71.TabIndex = 29;
            this.button71.UseVisualStyleBackColor = false;
            // 
            // button72
            // 
            this.button72.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button72.FlatAppearance.BorderSize = 0;
            this.button72.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button72.Location = new System.Drawing.Point(79, 234);
            this.button72.Name = "button72";
            this.button72.Size = new System.Drawing.Size(20, 20);
            this.button72.TabIndex = 28;
            this.button72.UseVisualStyleBackColor = false;
            // 
            // button73
            // 
            this.button73.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button73.FlatAppearance.BorderSize = 0;
            this.button73.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button73.Location = new System.Drawing.Point(79, 208);
            this.button73.Name = "button73";
            this.button73.Size = new System.Drawing.Size(20, 20);
            this.button73.TabIndex = 27;
            this.button73.UseVisualStyleBackColor = false;
            // 
            // button74
            // 
            this.button74.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button74.FlatAppearance.BorderSize = 0;
            this.button74.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button74.Location = new System.Drawing.Point(79, 182);
            this.button74.Name = "button74";
            this.button74.Size = new System.Drawing.Size(20, 20);
            this.button74.TabIndex = 26;
            this.button74.UseVisualStyleBackColor = false;
            // 
            // button75
            // 
            this.button75.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button75.FlatAppearance.BorderSize = 0;
            this.button75.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button75.Location = new System.Drawing.Point(79, 156);
            this.button75.Name = "button75";
            this.button75.Size = new System.Drawing.Size(20, 20);
            this.button75.TabIndex = 25;
            this.button75.UseVisualStyleBackColor = false;
            // 
            // button76
            // 
            this.button76.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button76.FlatAppearance.BorderSize = 0;
            this.button76.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button76.Location = new System.Drawing.Point(79, 130);
            this.button76.Name = "button76";
            this.button76.Size = new System.Drawing.Size(20, 20);
            this.button76.TabIndex = 24;
            this.button76.UseVisualStyleBackColor = false;
            // 
            // button77
            // 
            this.button77.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button77.FlatAppearance.BorderSize = 0;
            this.button77.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button77.Location = new System.Drawing.Point(79, 104);
            this.button77.Name = "button77";
            this.button77.Size = new System.Drawing.Size(20, 20);
            this.button77.TabIndex = 23;
            this.button77.UseVisualStyleBackColor = false;
            // 
            // button78
            // 
            this.button78.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button78.FlatAppearance.BorderSize = 0;
            this.button78.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button78.Location = new System.Drawing.Point(79, 78);
            this.button78.Name = "button78";
            this.button78.Size = new System.Drawing.Size(20, 20);
            this.button78.TabIndex = 22;
            this.button78.UseVisualStyleBackColor = false;
            // 
            // button79
            // 
            this.button79.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button79.FlatAppearance.BorderSize = 0;
            this.button79.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button79.Location = new System.Drawing.Point(79, 52);
            this.button79.Name = "button79";
            this.button79.Size = new System.Drawing.Size(20, 20);
            this.button79.TabIndex = 21;
            this.button79.UseVisualStyleBackColor = false;
            // 
            // button80
            // 
            this.button80.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button80.FlatAppearance.BorderSize = 0;
            this.button80.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button80.Location = new System.Drawing.Point(79, 26);
            this.button80.Name = "button80";
            this.button80.Size = new System.Drawing.Size(20, 20);
            this.button80.TabIndex = 20;
            this.button80.UseVisualStyleBackColor = false;
            // 
            // button81
            // 
            this.button81.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button81.FlatAppearance.BorderSize = 0;
            this.button81.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button81.Location = new System.Drawing.Point(53, 260);
            this.button81.Name = "button81";
            this.button81.Size = new System.Drawing.Size(20, 20);
            this.button81.TabIndex = 19;
            this.button81.UseVisualStyleBackColor = false;
            // 
            // button82
            // 
            this.button82.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button82.FlatAppearance.BorderSize = 0;
            this.button82.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button82.Location = new System.Drawing.Point(53, 234);
            this.button82.Name = "button82";
            this.button82.Size = new System.Drawing.Size(20, 20);
            this.button82.TabIndex = 18;
            this.button82.UseVisualStyleBackColor = false;
            // 
            // button83
            // 
            this.button83.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button83.FlatAppearance.BorderSize = 0;
            this.button83.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button83.Location = new System.Drawing.Point(53, 208);
            this.button83.Name = "button83";
            this.button83.Size = new System.Drawing.Size(20, 20);
            this.button83.TabIndex = 17;
            this.button83.UseVisualStyleBackColor = false;
            // 
            // button84
            // 
            this.button84.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button84.FlatAppearance.BorderSize = 0;
            this.button84.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button84.Location = new System.Drawing.Point(53, 182);
            this.button84.Name = "button84";
            this.button84.Size = new System.Drawing.Size(20, 20);
            this.button84.TabIndex = 16;
            this.button84.UseVisualStyleBackColor = false;
            // 
            // button85
            // 
            this.button85.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button85.FlatAppearance.BorderSize = 0;
            this.button85.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button85.Location = new System.Drawing.Point(53, 156);
            this.button85.Name = "button85";
            this.button85.Size = new System.Drawing.Size(20, 20);
            this.button85.TabIndex = 15;
            this.button85.UseVisualStyleBackColor = false;
            // 
            // button86
            // 
            this.button86.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button86.FlatAppearance.BorderSize = 0;
            this.button86.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button86.Location = new System.Drawing.Point(53, 130);
            this.button86.Name = "button86";
            this.button86.Size = new System.Drawing.Size(20, 20);
            this.button86.TabIndex = 14;
            this.button86.UseVisualStyleBackColor = false;
            // 
            // button87
            // 
            this.button87.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button87.FlatAppearance.BorderSize = 0;
            this.button87.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button87.Location = new System.Drawing.Point(53, 104);
            this.button87.Name = "button87";
            this.button87.Size = new System.Drawing.Size(20, 20);
            this.button87.TabIndex = 13;
            this.button87.UseVisualStyleBackColor = false;
            // 
            // button88
            // 
            this.button88.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button88.FlatAppearance.BorderSize = 0;
            this.button88.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button88.Location = new System.Drawing.Point(53, 78);
            this.button88.Name = "button88";
            this.button88.Size = new System.Drawing.Size(20, 20);
            this.button88.TabIndex = 12;
            this.button88.UseVisualStyleBackColor = false;
            // 
            // button89
            // 
            this.button89.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button89.FlatAppearance.BorderSize = 0;
            this.button89.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button89.Location = new System.Drawing.Point(53, 52);
            this.button89.Name = "button89";
            this.button89.Size = new System.Drawing.Size(20, 20);
            this.button89.TabIndex = 11;
            this.button89.UseVisualStyleBackColor = false;
            // 
            // button90
            // 
            this.button90.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button90.FlatAppearance.BorderSize = 0;
            this.button90.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button90.Location = new System.Drawing.Point(53, 26);
            this.button90.Name = "button90";
            this.button90.Size = new System.Drawing.Size(20, 20);
            this.button90.TabIndex = 10;
            this.button90.UseVisualStyleBackColor = false;
            // 
            // button91
            // 
            this.button91.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button91.FlatAppearance.BorderSize = 0;
            this.button91.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button91.Location = new System.Drawing.Point(27, 260);
            this.button91.Name = "button91";
            this.button91.Size = new System.Drawing.Size(20, 20);
            this.button91.TabIndex = 9;
            this.button91.UseVisualStyleBackColor = false;
            // 
            // button92
            // 
            this.button92.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button92.FlatAppearance.BorderSize = 0;
            this.button92.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button92.Location = new System.Drawing.Point(27, 234);
            this.button92.Name = "button92";
            this.button92.Size = new System.Drawing.Size(20, 20);
            this.button92.TabIndex = 8;
            this.button92.UseVisualStyleBackColor = false;
            // 
            // button93
            // 
            this.button93.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button93.FlatAppearance.BorderSize = 0;
            this.button93.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button93.Location = new System.Drawing.Point(27, 208);
            this.button93.Name = "button93";
            this.button93.Size = new System.Drawing.Size(20, 20);
            this.button93.TabIndex = 7;
            this.button93.UseVisualStyleBackColor = false;
            // 
            // button94
            // 
            this.button94.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button94.FlatAppearance.BorderSize = 0;
            this.button94.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button94.Location = new System.Drawing.Point(27, 182);
            this.button94.Name = "button94";
            this.button94.Size = new System.Drawing.Size(20, 20);
            this.button94.TabIndex = 6;
            this.button94.UseVisualStyleBackColor = false;
            // 
            // button95
            // 
            this.button95.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button95.FlatAppearance.BorderSize = 0;
            this.button95.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button95.Location = new System.Drawing.Point(27, 156);
            this.button95.Name = "button95";
            this.button95.Size = new System.Drawing.Size(20, 20);
            this.button95.TabIndex = 5;
            this.button95.UseVisualStyleBackColor = false;
            // 
            // button96
            // 
            this.button96.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button96.FlatAppearance.BorderSize = 0;
            this.button96.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button96.Location = new System.Drawing.Point(27, 130);
            this.button96.Name = "button96";
            this.button96.Size = new System.Drawing.Size(20, 20);
            this.button96.TabIndex = 4;
            this.button96.UseVisualStyleBackColor = false;
            // 
            // button97
            // 
            this.button97.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button97.FlatAppearance.BorderSize = 0;
            this.button97.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button97.Location = new System.Drawing.Point(27, 104);
            this.button97.Name = "button97";
            this.button97.Size = new System.Drawing.Size(20, 20);
            this.button97.TabIndex = 3;
            this.button97.UseVisualStyleBackColor = false;
            // 
            // button98
            // 
            this.button98.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button98.FlatAppearance.BorderSize = 0;
            this.button98.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button98.Location = new System.Drawing.Point(27, 78);
            this.button98.Name = "button98";
            this.button98.Size = new System.Drawing.Size(20, 20);
            this.button98.TabIndex = 2;
            this.button98.UseVisualStyleBackColor = false;
            // 
            // button99
            // 
            this.button99.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button99.FlatAppearance.BorderSize = 0;
            this.button99.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button99.Location = new System.Drawing.Point(27, 52);
            this.button99.Name = "button99";
            this.button99.Size = new System.Drawing.Size(20, 20);
            this.button99.TabIndex = 1;
            this.button99.UseVisualStyleBackColor = false;
            // 
            // button100
            // 
            this.button100.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button100.FlatAppearance.BorderSize = 0;
            this.button100.FlatAppearance.MouseOverBackColor = System.Drawing.Color.WhiteSmoke;
            this.button100.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button100.Location = new System.Drawing.Point(27, 26);
            this.button100.Name = "button100";
            this.button100.Size = new System.Drawing.Size(20, 20);
            this.button100.TabIndex = 0;
            this.button100.UseVisualStyleBackColor = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::BattleShipForms.Properties.Resources.Boat2Big;
            this.pictureBox5.Location = new System.Drawing.Point(335, 205);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(71, 64);
            this.pictureBox5.TabIndex = 11;
            this.pictureBox5.TabStop = false;
            // 
            // button101
            // 
            this.button101.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.button101.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button101.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button101.Location = new System.Drawing.Point(319, 291);
            this.button101.Name = "button101";
            this.button101.Size = new System.Drawing.Size(104, 72);
            this.button101.TabIndex = 12;
            this.button101.Text = "Generate Random Positions";
            this.button101.UseVisualStyleBackColor = false;
            this.button101.Click += new System.EventHandler(this.button101_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 500;
            // 
            // GamePanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(782, 593);
            this.Controls.Add(this.button101);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.label53);
            this.Controls.Add(this.label51);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.label52);
            this.Controls.Add(this.label48);
            this.Controls.Add(this.label47);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Cursor = System.Windows.Forms.Cursors.No;
            this.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "GamePanel";
            this.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "BattleShip";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Panel panel1;
        private Panel panel2;
        private Label label16;
        private Label label17;
        private Label label18;
        private Label label19;
        private Label label20;
        private Label label15;
        private Label label14;
        private Label label13;
        private Label label12;
        private Label label11;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private Button j10;
        private Button j9;
        private Button j8;
        private Button j7;
        private Button j6;
        private Button j5;
        private Button j4;
        private Button j3;
        private Button j2;
        private Button j1;
        private Button i10;
        private Button i9;
        private Button i8;
        private Button i7;
        private Button i6;
        private Button i5;
        private Button i4;
        private Button i3;
        private Button i2;
        private Button i1;
        private Button h10;
        private Button h9;
        private Button h8;
        private Button h7;
        private Button h6;
        private Button h5;
        private Button h4;
        private Button h3;
        private Button h2;
        private Button h1;
        private Button g10;
        private Button g9;
        private Button g8;
        private Button g7;
        private Button g6;
        private Button g5;
        private Button g4;
        private Button g3;
        private Button g2;
        private Button g1;
        private Button f10;
        private Button f9;
        private Button f8;
        private Button f7;
        private Button f6;
        private Button f5;
        private Button f4;
        private Button f3;
        private Button f2;
        private Button f1;
        private Button e10;
        private Button e9;
        private Button e8;
        private Button e7;
        private Button e6;
        private Button e5;
        private Button e4;
        private Button e3;
        private Button e2;
        private Button e1;
        private Button d10;
        private Button d9;
        private Button d8;
        private Button d7;
        private Button d6;
        private Button d5;
        private Button d4;
        private Button d3;
        private Button d2;
        private Button d1;
        private Button c10;
        private Button c9;
        private Button c8;
        private Button c7;
        private Button c6;
        private Button c5;
        private Button c4;
        private Button c3;
        private Button c2;
        private Button c1;
        private Button b10;
        private Button b9;
        private Button bb8;
        private Button b7;
        private Button b6;
        private Button b5;
        private Button b4;
        private Button b3;
        private Button b2;
        private Button b1;
        private Button a10;
        private Button a9;
        private Button a8;
        private Button a7;
        private Button a6;
        private Button a5;
        private Button a4;
        private Button a3;
        private Button a2;
        private Button a1;
        private Label label21;
        private PictureBox pictureBox1;
        private Label label22;
        private Label label23;
        private Label label24;
        private Panel panel3;
        private Label label40;
        private Label label41;
        private PictureBox pictureBox4;
        private Label label42;
        private Label label43;
        private Label label44;
        private Label label45;
        private Label label34;
        private Label label35;
        private PictureBox pictureBox3;
        private Label label36;
        private Label label37;
        private Label label38;
        private Label label39;
        private Label label28;
        private Label label29;
        private PictureBox pictureBox2;
        private Label label30;
        private Label label31;
        private Label label32;
        private Label label33;
        private Label label26;
        private Label label27;
        private Label label51;
        private Label label49;
        private Label label48;
        private Label label47;
        private Label label46;
        private Label label52;
        private Label label53;
        private Panel panel4;
        private Label label54;
        private Label label55;
        private Label label56;
        private Label label57;
        private Label label58;
        private Label label59;
        private Label label60;
        private Label label61;
        private Label label62;
        private Label label63;
        private Label label64;
        private Label label65;
        private Label label66;
        private Label label67;
        private Label label68;
        private Label label69;
        private Label label70;
        private Label label71;
        private Label label72;
        private Label label73;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
        private Button button10;
        private Button button11;
        private Button button12;
        private Button button13;
        private Button button14;
        private Button button15;
        private Button button16;
        private Button button17;
        private Button button18;
        private Button button19;
        private Button button20;
        private Button button21;
        private Button button22;
        private Button button23;
        private Button button24;
        private Button button25;
        private Button button26;
        private Button button27;
        private Button button28;
        private Button button29;
        private Button button30;
        private Button button31;
        private Button button32;
        private Button button33;
        private Button button34;
        private Button button35;
        private Button button36;
        private Button button37;
        private Button button38;
        private Button button39;
        private Button button40;
        private Button button41;
        private Button button42;
        private Button button43;
        private Button button44;
        private Button button45;
        private Button button46;
        private Button button47;
        private Button button48;
        private Button button49;
        private Button button50;
        private Button button51;
        private Button button52;
        private Button button53;
        private Button button54;
        private Button button55;
        private Button button56;
        private Button button57;
        private Button button58;
        private Button button59;
        private Button button60;
        private Button button61;
        private Button button62;
        private Button button63;
        private Button button64;
        private Button button65;
        private Button button66;
        private Button button67;
        private Button button68;
        private Button button69;
        private Button button70;
        private Button button71;
        private Button button72;
        private Button button73;
        private Button button74;
        private Button button75;
        private Button button76;
        private Button button77;
        private Button button78;
        private Button button79;
        private Button button80;
        private Button button81;
        private Button button82;
        private Button button83;
        private Button button84;
        private Button button85;
        private Button button86;
        private Button button87;
        private Button button88;
        private Button button89;
        private Button button90;
        private Button button91;
        private Button button92;
        private Button button93;
        private Button button94;
        private Button button95;
        private Button button96;
        private Button button97;
        private Button button98;
        private Button button99;
        private Button button100;
        private PictureBox pictureBox5;
        private Button button101;
        private System.Windows.Forms.Timer timer1;
        public Label label25;
    }
}